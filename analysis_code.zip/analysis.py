import numpy as np, pandas as pd, pickle, sys, time
from multiprocessing import Pool
from core import *
from core import _std

OUTS = ["ms", "any", "mb", "crnmb", "vte", "death", "reint", "nc"]
d0, v0 = load()
B_MAIN = 1000
B_SENS = 500


def estimate(d, tiers=DEFAULT_TIERS, wr=True, **kw):
    cl = build_clones(d.reset_index(drop=True), **kw)
    A, B = cl["A"], cl["B"]
    res = {}
    for k in OUTS:
        ra, _ = wAJ(A, k); rb, _ = wAJ(B, k)
        for t in (365, 730):
            res[f"{k}_{t}_A"] = ra[t]; res[f"{k}_{t}_B"] = rb[t]
            res[f"{k}_{t}_RD"] = ra[t] - rb[t]
            res[f"{k}_{t}_RR"] = ra[t] / rb[t] if rb[t] > 0 else np.nan
    if wr:
        r = win_ratio(A, B, tiers)
        res.update({k: r[k] for k in ["WR", "WO", "NB", "pW", "pL", "pT"]})
        for k, w, l in r["tiers"]:
            res[f"tier_{k}_W"] = w; res[f"tier_{k}_L"] = l
    return res


# ------------------------------------------------------------- landmark design
def landmark_data(d):
    # exclude patients with death/VTE/major bleeding or censoring before end of grace period (day 7)
    early = np.zeros(len(d), bool)
    for k in ["death", "vte", "mb"]:
        early |= (d[k] == 1) & (d[k + "_t"] <= GRACE)
    early |= d.fu <= GRACE
    return d[~early].reset_index(drop=True)


def landmark_clones(d, method="overlap", trunc=99):
    X = _std(covmat(d))
    a = d.trt.values
    ps = fit_logit(X, a).predict_proba(X)[:, 1]
    if method == "overlap":
        w = np.where(a == 1, 1 - ps, ps)
    else:
        w = np.where(a == 1, 1 / ps, 1 / (1 - ps))
        if trunc is not None:
            w = np.minimum(w, np.percentile(w, trunc))
    n = len(d)
    out = {}
    for arm, sel in (("A", a == 1), ("B", a == 0)):
        fu = np.where(sel, d.fu.values, 0.0); pf = np.where(sel, d.ptsfu.values, 0.0)
        ev = {}
        for k in ["death", "vte", "mb", "crnmb", "reint", "nc"]:
            t = np.where(d[k].values == 1, d[k + "_t"].values, np.inf)
            ev[k] = np.where(sel & (t <= fu), t, np.inf)
        for k in ["any", "ms"]:
            t = d[k + "_t"].values.astype(float); t = np.where(np.isnan(t), np.inf, t)
            ev[k] = np.where(sel & (t <= pf), t, np.inf)
        o = dict(fu=fu, pf=pf, post=np.where(sel, w, 0.0), gw=np.ones((n, GRACE + 1)) * np.where(sel, 1, 0)[:, None],
                 ev=ev, uncens=sel)
        ct = d.fu.values.astype(float); ci = d.ltfu.values
        Gc = np.ones((n, len(CLIN_GRID))); Gc[sel] = discrete_cens_G(d, sel, ct, ci, CLIN_GRID)
        nextvisit = np.array([next((g for g in PTS_GRID if g > p), np.inf) for p in d.ptsfu.values])
        pci = ((d.ptsfu.values < HORIZON) & ~((d.death.values == 1) & (d.death_t.values < nextvisit))).astype(int)
        pct = np.where(pci == 1, nextvisit, np.where(d.death.values == 1, d.death_t.values, HORIZON))
        Gp = np.ones((n, len(PTS_GRID))); Gp[sel] = discrete_cens_G(d, sel, pct, pci, PTS_GRID)
        o["Gc"] = Gc; o["Gp"] = Gp
        out[arm] = o
    return out, ps, w


def estimate_landmark(d, method="overlap", wr=True):
    d = landmark_data(d.reset_index(drop=True))
    cl, ps, w = landmark_clones(d, method)
    A, B = cl["A"], cl["B"]
    res = {}
    for k in OUTS:
        ra, _ = wAJ(A, k); rb, _ = wAJ(B, k)
        for t in (365, 730):
            res[f"{k}_{t}_A"] = ra[t]; res[f"{k}_{t}_B"] = rb[t]
            res[f"{k}_{t}_RD"] = ra[t] - rb[t]
            res[f"{k}_{t}_RR"] = ra[t] / rb[t] if rb[t] > 0 else np.nan
    if wr:
        r = win_ratio(A, B)
        res.update({k: r[k] for k in ["WR", "WO", "NB", "pW", "pL", "pT"]})
    return res


def binary_y(d, key="ms"):
    """Cumulative outcome by 24 months: observed if event detected, died, or completed 24-month visit."""
    t = d[key + "_t"].values
    y = (~np.isnan(t)).astype(float)
    obs = (y == 1) | (d.ptsfu.values >= HORIZON) | (d.death.values == 1)
    return y, obs


def aipw(d, key="ms"):
    d = landmark_data(d.reset_index(drop=True))
    X = _std(covmat(d)); a = d.trt.values
    y, obs = binary_y(d, key)
    ps = fit_logit(X, a).predict_proba(X)[:, 1]
    ps = np.clip(ps, 0.01, 0.99)
    XA = np.column_stack([X, a])
    pr = fit_logit(XA, obs.astype(int), C=1.0).predict_proba(XA)[:, 1]
    om = fit_logit(XA[obs], y[obs], C=1.0)
    mu1 = om.predict_proba(np.column_stack([X, np.ones(len(a))]))[:, 1]
    mu0 = om.predict_proba(np.column_stack([X, np.zeros(len(a))]))[:, 1]
    yy = np.where(obs, y, 0)
    psi1 = np.mean(mu1 + a * obs / (ps * pr) * (yy - mu1))
    psi0 = np.mean(mu0 + (1 - a) * obs / ((1 - ps) * pr) * (yy - mu0))
    return dict(A=psi1, B=psi0, RD=psi1 - psi0, RR=psi1 / psi0)


# ------------------------------------------------------------- bootstrap
def boot_idx(d, rng):
    idx = []
    for c, g in d.groupby("center").groups.items():
        g = np.array(list(g))
        idx.append(rng.choice(g, size=len(g), replace=True))
    return np.concatenate(idx)


def _boot_worker(args):
    fn, kw, seed, nb, dsel = args
    rng = np.random.default_rng(seed)
    d = d0.loc[dsel].reset_index(drop=True) if dsel is not None else d0
    out = []
    for b in range(nb):
        db = d.loc[boot_idx(d, rng)].reset_index(drop=True)
        try:
            out.append(fn(db, **kw))
        except Exception as e:
            out.append(None)
    return out


def bootstrap(fn, kw, nb, seed, dsel=None, procs=2):
    per = nb // procs
    with Pool(procs) as p:
        parts = p.map(_boot_worker, [(fn, kw, seed + i, per, dsel) for i in range(procs)])
    return [r for part in parts for r in part if r is not None]


def summarize(point, boots):
    s = {}
    for k, v in point.items():
        arr = np.array([b[k] for b in boots if k in b and b[k] is not None and np.isfinite(b[k])])
        if k in ("WR", "WO") or k.endswith("_RR"):
            arr = arr[arr > 0]
        if arr.size < 10 or not np.isfinite(v):
            s[k] = (v, np.nan, np.nan, np.nan); continue
        if k in ("WR", "WO") or k.endswith("_RR"):
            la = np.log(arr[arr > 0])
            lo, hi = np.exp(np.percentile(la, [2.5, 97.5]))
            se = la.std(ddof=1)
            z = np.log(v) / se if v > 0 else np.nan
        else:
            lo, hi = np.percentile(arr, [2.5, 97.5])
            se = arr.std(ddof=1); z = v / se if se > 0 else np.nan
        from scipy.stats import norm
        p = 2 * (1 - norm.cdf(abs(z))) if np.isfinite(z) else np.nan
        s[k] = (v, lo, hi, p)
    return s


def wrap_aipw(d, key="ms"):
    return aipw(d, key)


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "main"
    R = {}
    t0 = time.time()
    if which == "main":
        pt = estimate(d0)
        bs = bootstrap(estimate, {}, B_MAIN, 1000)
        R["main"] = summarize(pt, bs)
        print("main done", time.time() - t0, flush=True)
        pickle.dump(R, open("res_main.pkl", "wb"))
    elif which == "sens":
        specs = {
            "S1_grace3": (estimate, dict(grace=3), None),
            "S1_grace5": (estimate, dict(grace=5), None),
            "S2_pp": (estimate, dict(pp=True), None),
            "S3_overlap": (estimate_landmark, dict(method="overlap"), None),
            "S3_iptw": (estimate_landmark, dict(method="iptw"), None),
            "S3_aipw_ms": (wrap_aipw, dict(key="ms"), None),
            "S3_aipw_any": (wrap_aipw, dict(key="any"), None),
            "S4_pmt": (estimate, {}, (d0.method != 1).values),
            "S5_2019on": (estimate, {}, (d0.year >= 2019).values),
            "S9_t95": (estimate, dict(trunc=95), None),
            "S9_t995": (estimate, dict(trunc=99.5), None),
            "S9_none": (estimate, dict(trunc=None), None),
            "S10_noltfu": (estimate, dict(ltfu_ipcw=False), None),
            "S8_bleedfirst": (estimate, dict(tiers=[("death", "clin"), ("mb", "clin"), ("vte", "clin"), ("ms", "pts"), ("any", "pts")]), None),
            "S8_ptsfirst": (estimate, dict(tiers=[("death", "clin"), ("ms", "pts"), ("vte", "clin"), ("mb", "clin"), ("any", "pts")]), None),
            "S8_crnmb": (estimate, dict(tiers=[("death", "clin"), ("vte", "clin"), ("mb", "clin"), ("crnmb", "clin"), ("ms", "pts"), ("any", "pts")]), None),
        }
        for i, (name, (fn, kw, sel)) in enumerate(specs.items()):
            dd = d0.loc[sel].reset_index(drop=True) if sel is not None else d0
            pt = fn(dd, **kw)
            bs = bootstrap(fn, kw, B_SENS, 2000 + 10 * i, dsel=sel)
            R[name] = summarize(pt, bs)
            print(name, round(time.time() - t0), flush=True)
            pickle.dump(R, open("res_sens.pkl", "wb"))
    elif which == "sub":
        subs = {
            "symdur_le7": d0.symdur <= 7, "symdur_gt7": d0.symdur > 7,
            "iliac_yes": d0.iliac == 1, "iliac_no": d0.iliac == 0,
            "age_lt50": d0.age < 50, "age_ge50": d0.age >= 50,
            "mts_yes": d0.mts == 1, "mts_no": d0.mts == 0,
        }
        from core import COV_CONT, COV_BIN, COV_CTR
        for i, (name, sel) in enumerate(subs.items()):
            sel = sel.values
            pt = estimate(d0.loc[sel].reset_index(drop=True))
            bs = bootstrap(estimate, {}, B_SENS, 3000 + 10 * i, dsel=sel)
            R[name] = dict(summ=summarize(pt, bs), boots=[{k: b[k] for k in ("WR", "ms_730_RD", "mb_730_RD")} for b in bs], n=int(sel.sum()), nA=int(d0.trt[sel].sum()))
            print(name, round(time.time() - t0), flush=True)
            pickle.dump(R, open("res_sub.pkl", "wb"))
