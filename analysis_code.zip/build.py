import json, pickle, numpy as np
from scipy.stats import norm
from core import load

d, v = load()
M = pickle.load(open("res_main.pkl", "rb"))["main"]
S = pickle.load(open("res_sens.pkl", "rb"))
SUB = pickle.load(open("res_sub.pkl", "rb"))
D = pickle.load(open("res_desc.pkl", "rb"))
H = pickle.load(open("res_hte.pkl", "rb"))
SL = pickle.load(open("res_slcf.pkl", "rb"))
nA, nB, N = int(d.trt.sum()), int((1 - d.trt).sum()), len(d)


def pc(x, k=1): return f"{x*100:.{k}f}%"
def pp(x, k=1): return f"{x*100:.{k}f}"
def sg(x, k=1): return f"{x*100:+.{k}f}".replace("+", "+").replace("-", "−")
def P(p):
    if p is None or not np.isfinite(p): return "—"
    return "<0.001" if p < 0.001 else f"{p:.3f}" if p < 0.01 else f"{p:.2f}"
def rdci(t): return f"{sg(t[0])}（{sg(t[1])} 至 {sg(t[2])}）"
def rrci(t): return f"{t[0]:.2f}（{t[1]:.2f}–{t[2]:.2f}）"
def wrci(t): return f"{t[0]:.2f}（95% CI {t[1]:.2f}–{t[2]:.2f}）"


def evalue(rr):
    rr = 1 / rr if rr < 1 else rr
    return rr + np.sqrt(rr * (rr - 1))


E_ms = evalue(M["ms_730_RR"][0]); E_ms_ci = evalue(M["ms_730_RR"][2]) if M["ms_730_RR"][2] < 1 else 1.0
E_mb = evalue(M["mb_730_RR"][0]); E_mb_ci = evalue(M["mb_730_RR"][1]) if M["mb_730_RR"][1] > 1 else 1.0
bench = max(H["bench"], key=lambda b: min(max(b[1], 1 / b[1]), max(b[2], 1 / b[2])))
bench_name = {"age": "年龄", "iliac": "髂静脉受累", "mts": "髂静脉压迫综合征", "extent": "血栓累及范围评分较高", "symdur": "症状持续时间", "pain": "基线疼痛评分较高",
              "stroke": "既往脑卒中", "bleedscore": "出血风险评分", "c3": "中心 3", "c4": "中心 4", "bmi": "BMI"}[bench[0]]

T = D["trt"]; F = D["fu"]; W = D["weights"]; CS = D["cross"]; tb = D["table2"]
mx_c, mx_w = tb.smd_crude.abs().max(), tb.smd_w.abs().max()
n_imb = int((tb.smd_crude.abs() > 0.1).sum())
day_med = T["day_median"]; day_q = T["day_q"]
mt = T["method"]
cr = D["crude"]

# subgroup interaction
def inter(a, b, key):
    xa = np.array([x[key] for x in SUB[a]["boots"]]); xb = np.array([x[key] for x in SUB[b]["boots"]])
    if key == "WR":
        xa, xb = np.log(xa[xa > 0]), np.log(xb[xb > 0])
        diff = np.log(SUB[a]["summ"]["WR"][0]) - np.log(SUB[b]["summ"]["WR"][0])
    else:
        diff = SUB[a]["summ"][key][0] - SUB[b]["summ"][key][0]
    se = np.sqrt(xa.var(ddof=1) + xb.var(ddof=1))
    return 2 * (1 - norm.cdf(abs(diff / se)))

B = []
def h1(t): B.append(dict(type="h1", text=t))
def h2(t): B.append(dict(type="h2", text=t))
def h3(t): B.append(dict(type="h3", text=t))
def p(t, **k): B.append(dict(type="p", text=t, **k))
def ab(t): B.append(dict(type="abs", text=t))
def cap(t): B.append(dict(type="caption", text=t, keep=("表" in t[:8])))
def note(t): B.append(dict(type="note", text=t))
def tab(header, rows, widths=None): B.append(dict(type="table", header=header, rows=rows, widths=widths))
def img(path, ratio, width=600): B.append(dict(type="img", path=path, ratio=ratio, width=width))
def pb(): B.append(dict(type="pagebreak"))

wr = M["WR"]; wo = M["WO"]; nb = M["NB"]
ms = M["ms_730_RD"]; mb = M["mb_730_RD"]
NNT = 1 / -ms[0]; NNH = 1 / mb[0]

# =========================================================== TITLE PAGE
B.append(dict(type="title", text="早期血栓清除联合抗凝与单纯抗凝治疗急性髂股静脉血栓形成：基于分层复合结局的多中心目标试验模拟研究"))
B.append(dict(type="subtitle", text="_Early thrombus removal plus anticoagulation versus anticoagulation alone for acute iliofemoral deep vein thrombosis: a multicenter target trial emulation using a hierarchical composite outcome_"))
B.append(dict(type="subtitle", text="【作者姓名】^1^，【作者姓名】^2^，【作者姓名】^3^，【通信作者】^1^"))
B.append(dict(type="subtitle", text="^1^【单位，城市，邮编】；^2^【单位】；^3^【单位】"))
B.append(dict(type="subtitle", text="通信作者：【姓名】，Email：【邮箱】"))
note("说明：方括号【】内为需作者补充或核实的信息；文中全部统计数字均由本研究数据集直接计算生成。")

# =========================================================== ABSTRACT
h1("摘要")
ab(f"**目的** 在真实世界多中心数据中模拟一项随机对照试验，比较急性髂股静脉深静脉血栓形成（DVT）患者确诊后 7 天内行血栓清除［导管接触溶栓（CDT）和/或药物机械血栓清除（PMT），±髂静脉支架］联合抗凝与单纯抗凝的 24 个月净临床获益。")
ab(f"**方法** 回顾性纳入 2016—2024 年 4 家中心符合目标试验纳排标准的急性髂股 DVT 患者 {N} 例。按 TARGET 声明设计目标试验模拟：以影像确诊日为零时点，宽限期 7 天，采用克隆—删失—加权（CCW）法消除不朽时间偏倚，以逆概率删失权重（IPCW）校正人为删失与失访。主要结局为 24 个月分层复合结局，依次比较全因死亡、复发静脉血栓栓塞（VTE）、ISTH 大出血、中重度血栓后综合征（PTS，Villalta ≥10 分或溃疡）和任意 PTS（Villalta ≥5 分），以 IPCW 校正的 win ratio 表示；次要结局以加权 Aalen–Johansen 法估计累积发生率（死亡为竞争风险）。置信区间由按中心分层、重新估计权重的 bootstrap（{1000} 次）获得。另行地标设计（重叠权重、增强逆概率加权及 SuperLearner 交叉拟合双稳健估计）、多项敏感性分析、阴性对照结局、E 值、预设亚组、基于风险的疗效异质性分析和探索性因果森林分析。")
ab(f"**结果** {nA} 例（{pp(nA/N)}%）在 7 天内接受血栓清除（中位第 {day_med:.0f} 天），{nB} 例单纯抗凝。加权后所有基线协变量标准化均数差 <0.1。24 个月加权 win ratio 为 {wrci(wr)}，P = {P(wr[3])}；win odds 为 {wo[0]:.2f}（{wo[1]:.2f}–{wo[2]:.2f}），净获益 {sg(nb[0])}%（{sg(nb[1])}% 至 {sg(nb[2])}%）。早期血栓清除组 24 个月中重度 PTS 累积发生率为 {pc(M['ms_730_A'][0])}，单纯抗凝组为 {pc(M['ms_730_B'][0])}［风险差（RD）{sg(ms[0])}%，95% CI {sg(ms[1])}% 至 {sg(ms[2])}%；RR {rrci(M['ms_730_RR'])}］；任意 PTS 分别为 {pc(M['any_730_A'][0])} 和 {pc(M['any_730_B'][0])}（RD {sg(M['any_730_RD'][0])}%）；大出血分别为 {pc(M['mb_730_A'][0])} 和 {pc(M['mb_730_B'][0])}（RD {sg(mb[0])}%，95% CI {sg(mb[1])}% 至 {sg(mb[2])}%），且介入组大出血均发生于确诊 6 周以后。复发 VTE 与全因死亡差异无统计学意义。地标设计与双稳健估计结果一致；将中重度 PTS 层前置时 win ratio 为 {S['S8_ptsfirst']['WR'][0]:.2f}（{S['S8_ptsfirst']['WR'][1]:.2f}–{S['S8_ptsfirst']['WR'][2]:.2f}），宽限期缩短至 3 天时降至 {S['S1_grace3']['WR'][0]:.2f}。")
ab(f"**结论** 在真实世界急性髂股 DVT 人群中，早期血栓清除使中重度 PTS 的 24 个月绝对风险降低约 11 个百分点（每治疗约 {NNT:.0f} 例减少 1 例），但伴随约 5 个百分点的大出血绝对风险增加（每治疗约 {NNH:.0f} 例增加 1 例）；在同时计入死亡、复发 VTE 和出血的分层复合结局上，获益未达统计学意义。血栓清除的决策应权衡 PTS 获益与出血风险，并关注介入后长期抗栓管理。")
ab("**关键词** 深静脉血栓形成；髂股静脉；血栓后综合征；导管接触溶栓；药物机械血栓清除；目标试验模拟；win ratio")

# English abstract
pb()
h2("Abstract")
ab(f"**Objective** To emulate a randomized trial comparing early thrombus removal (catheter-directed thrombolysis [CDT] and/or pharmacomechanical thrombectomy [PMT], with or without iliac stenting) within 7 days of diagnosis plus anticoagulation versus anticoagulation alone for acute iliofemoral deep vein thrombosis (DVT).")
ab(f"**Methods** We included {N} eligible patients from four centers (2016–2024). Following the TARGET statement, time zero was the date of imaging diagnosis with a 7-day grace period; a clone–censor–weight approach with inverse probability of censoring weights addressed immortal time and loss to follow-up. The primary outcome was a 24-month hierarchical composite (all-cause death, recurrent venous thromboembolism [VTE], ISTH major bleeding, moderate-to-severe post-thrombotic syndrome [PTS], any PTS) analyzed with an IPCW-adjusted win ratio. Secondary outcomes were weighted cumulative incidences with death as a competing risk. Confidence intervals came from a center-stratified bootstrap with re-estimated weights.")
ab(f"**Results** Overall, {nA} patients ({pp(nA/N)}%) underwent thrombus removal within 7 days and {nB} received anticoagulation alone. The win ratio was {wr[0]:.2f} (95% CI {wr[1]:.2f}–{wr[2]:.2f}; P = {P(wr[3])}). At 24 months, moderate-to-severe PTS occurred in {pc(M['ms_730_A'][0])} vs {pc(M['ms_730_B'][0])} (risk difference {ms[0]*100:.1f} percentage points, 95% CI {ms[1]*100:.1f} to {ms[2]*100:.1f}), whereas major bleeding occurred in {pc(M['mb_730_A'][0])} vs {pc(M['mb_730_B'][0])} (risk difference +{mb[0]*100:.1f}, 95% CI +{mb[1]*100:.1f} to +{mb[2]*100:.1f}). These component effects were consistent across landmark, overlap-weighted and doubly robust analyses, whereas the win ratio was sensitive to the ordering of outcome tiers.")
ab(f"**Conclusions** Early thrombus removal reduced moderate-to-severe PTS but increased major bleeding, and did not significantly improve a hierarchical composite of net clinical benefit at 24 months.")
ab("**Keywords** deep vein thrombosis; iliofemoral; post-thrombotic syndrome; catheter-directed thrombolysis; pharmacomechanical thrombectomy; target trial emulation; win ratio")
pb()

# =========================================================== INTRODUCTION
h1("1 引言")
p("血栓后综合征（post-thrombotic syndrome，PTS）是下肢深静脉血栓形成（deep vein thrombosis，DVT）最常见的远期并发症，表现为慢性肢体疼痛、沉重、水肿、皮肤改变乃至静脉性溃疡，显著降低生活质量并带来长期医疗负担^[1]^。在近端 DVT 中，血栓累及髂静脉和/或股总静脉（髂股 DVT）者流出道梗阻最重、PTS 风险最高^[1]^，而单纯股腘静脉血栓患者从血栓清除中获益并不明显^[2]^。早期清除血栓理论上可恢复静脉通畅、保护瓣膜功能并减少残余梗阻，从而降低 PTS 风险。")
p("然而，三项关键随机对照试验（randomized controlled trial，RCT）的结论并不一致。CaVenT 试验在 209 例髂股或股静脉 DVT 患者中显示，附加 CDT 使 24 个月 PTS 绝对风险降低 14.4%，且获益延续至 5 年^[3,4]^；ATTRACT 试验纳入 692 例近端 DVT，药物机械 CDT 未能降低 6～24 个月任意 PTS（47% vs 48%），但降低了中重度 PTS（18% vs 24%），并使 10 天内大出血增加（1.7% vs 0.3%）^[5]^；其髂股亚组分析同样提示中重度 PTS 和症状评分改善而任意 PTS 无差异^[6]^；CAVA 试验中超声加速 CDT 亦未显著降低 12 个月 PTS^[7]^。Cochrane 系统评价据此认为溶栓策略可能减少 PTS，但以出血增加为代价^[8]^。欧洲血管外科学会（ESVS）2021 指南与美国胸科医师学会（CHEST）指南对髂股 DVT 血栓清除均仅给予有条件推荐^[9,10]^，我国指南亦强调严格把握适应证^[11]^。因此，临床实践中治疗选择高度依赖医生偏好，形成了天然的“临床均势”。")
p("在新的大型 RCT 难以开展的情况下，利用真实世界数据回答“如果当初随机化，结论会如何”具有现实意义。但传统回顾性比较常将“随访中接受介入”的患者从零时点起归入介入组，引入不朽时间偏倚（immortal time bias）和选择偏倚^[12,13]^。目标试验模拟（target trial emulation，TTE）通过明确定义资格标准、治疗策略、零时点和因果对比，并借助克隆—删失—加权（clone–censor–weight，CCW）方法处理宽限期内的治疗启动，可在很大程度上避免上述自我造成的偏倚^[12–15]^。2025 年发布的 TARGET 声明进一步规范了此类研究的报告^[16]^。此外，单一 PTS 终点忽略了出血与死亡的权衡，而基于临床优先级的分层复合结局（win ratio）能在同一比较中同时体现疗效与安全性^[17–19]^。")
p("中国人群中 PMT（如 AngioJet）应用广泛、支架使用模式与欧美不同，但现有国内研究多为单中心、小样本的介入技术间比较^[20]^，缺乏与单纯抗凝的严格比较疗效证据。本研究基于 4 家中心的真实世界数据，按 TARGET 声明模拟目标试验，以 win ratio 分层复合结局为主要结局，评估急性髂股 DVT 早期血栓清除联合抗凝相对于单纯抗凝的 24 个月净临床获益，并探讨疗效异质性。")

# =========================================================== METHODS
h1("2 对象与方法")
h2("2.1 研究设计与数据来源")
p(f"本研究为多中心回顾性队列数据基础上的目标试验模拟，按 TARGET 声明报告^[16]^。数据来自 4 家医院血管外科【中心名称待填】2016 年 1 月至 2024 年【月份待填】影像确诊的急性髂股 DVT 患者，各中心分别贡献 {'、'.join(str(int(x)) for x in d.center.value_counts().sort_index().values)} 例。基线、治疗与结局资料采用统一变量字典和电子病例报告表提取，双人独立录入核对；12～24 个月结局缺失者以结构化电话随访补充，随访员不知晓患者治疗分组。研究经各中心伦理委员会批准并豁免书面知情同意（批件号【待填】），研究方案与统计分析计划已在结局数据提取前注册（注册号【待填】）。")
h2("2.2 目标试验规范")
p("表 1 列出了目标试验（理想 RCT）的各要素及其在观察性数据中的模拟方式。")
cap("**表 1** 目标试验规范与观察性数据模拟")
tab(["要素", "目标试验（理想 RCT）", "观察性数据模拟"], [
    ["纳入标准", "18～75 岁；影像确诊、累及髂静脉和/或股总静脉的急性症状性 DVT；症状 ≤14 天；两种策略均可实施", "同左；仅使用确诊日及之前的信息判定"],
    ["排除标准", "股青肿等肢体威胁；活动性恶性肿瘤；出血高危（近 3 个月脑卒中/手术/大出血、血小板 <100×10⁹/L、eGFR <30）；同侧既往 DVT；需系统溶栓的症状性 PE；妊娠", "同左"],
    ["治疗策略", "A：确诊后 7 天内启动 CDT 和/或 PMT（±球囊扩张/支架）+ 标准抗凝；B：单纯抗凝，不行血栓清除", "同左；宽限期 7 天；策略 B 中随访期间因症状加重行救治性介入属策略允许范围（ITT 类比不删失）"],
    ["分组", "随机、开放标签", "克隆后按实际治疗删失，以基线混杂因素构建 IPCW；假定无未测量混杂"],
    ["零时点", "随机化时刻", "影像确诊日（满足资格并开始随访）"],
    ["随访", "至死亡、失访或 24 个月", "同左；失访以 IPCW 校正"],
    ["结局", "主要：24 个月分层复合结局（win ratio）；次要：中重度/任意 PTS、大出血、CRNMB、复发 VTE、死亡、再次介入、Villalta 评分、VEINES-QOL、静脉通畅", "同左；PTS 来自门诊 Villalta 记录或盲法电话随访"],
    ["因果对比", "意向治疗（ITT）效应与符合方案（PP）效应", "ITT 类比为主；PP 类比为敏感性分析"],
    ["统计分析", "组间比较", "CCW + IPCW；加权 win ratio、加权 Aalen–Johansen 累积发生率；按中心分层 bootstrap"],
], widths=[0.14, 0.43, 0.43])
note("CDT：导管接触溶栓；PMT：药物机械血栓清除；IPCW：逆概率删失权重；CRNMB：临床相关非大出血；ITT：意向治疗；PP：符合方案。")

h2("2.3 治疗策略、零时点与克隆—删失—加权")
p("由于确诊当天并不知道患者最终是否会接受介入，若将“第 5 天接受 PMT”的患者自第 0 天归入介入组，前 5 天即为不朽时间。为此采用 CCW 法^[13–15]^：（1）克隆：零时点将每例患者复制为两份，分别分配至策略 A（7 天内血栓清除）和策略 B（单纯抗凝），两份克隆基线完全相同；（2）删失：策略 A 克隆若至第 7 天末仍未介入，则在第 7 天末删失；策略 B 克隆在介入当日删失；宽限期内（介入前）发生的结局事件同时计入两臂；（3）加权：在宽限期内将数据拆分为人—日格式，以池化 logistic 回归估计每日接受介入的风险（协变量为 2.5 节所列基线变量及以哑变量表示的天数），据此计算两臂未删失克隆的时间依赖性逆概率删失权重^[21]^。")
p("宽限期后的失访（随访不足 24 个月且未死亡）采用第二组 IPCW 校正：在每臂内以约 30 天为区间的离散时间池化 logistic 模型估计失访风险；对于仅在随访访视时评估的 PTS 结局，另以访视层面的模型估计 Villalta 评估缺失（之后不再有评估）的概率。治疗删失权重与失访权重分别在第 99 百分位截尾，二者相乘为最终权重。")
h2("2.4 结局定义")
p("**主要结局**为 24 个月分层复合结局。将策略 A 的每份克隆与策略 B 的每份克隆两两配对，按以下预设优先级在双方共同随访期内逐层比较，某层先发生事件者为“负”，分出胜负即停止：①全因死亡；②症状性、影像证实的复发 VTE（DVT 或肺栓塞）；③ISTH 大出血^[22]^；④中重度 PTS（6 个月后任一次评估 Villalta ≥10 分或出现静脉性溃疡）^[23]^；⑤任意 PTS（6 个月后任一次评估 Villalta ≥5 分）。前三层比较事件时间，后两层比较首次检出时间。所有层均无法区分且双方完成 24 个月随访的配对记为平局。")
p("**次要结局**包括上述各成分的 12 和 24 个月累积发生率，以及临床相关非大出血（CRNMB）^[24]^、再次静脉介入、6/12/24 个月 Villalta 总分、静脉疾病生活质量（VEINES-QOL）评分^[25]^和超声/CT 静脉通畅率。**阴性对照结局**为 24 个月内因感染性疾病（肺炎、泌尿系感染等）住院，该结局不应受血栓清除影响，但与健康意识、社会经济状况等潜在混杂相关^[26]^。")
h2("2.5 协变量")
p("混杂因素依据其同时影响治疗选择和结局的先验知识选择，而非单因素分析的 P 值，变量间假定的因果结构以有向无环图（DAG）表示（附图 S1）^[@dag]^。所有协变量均取零时点或之前的数值：年龄、性别、BMI、左侧 DVT、髂静脉受累、股总静脉受累、髂静脉压迫综合征、血栓累及范围评分、症状持续时间、基线疼痛评分、双下肢腿围差、诱发性 DVT、糖尿病、高血压、冠心病、既往脑卒中、Charlson 合并症指数、血红蛋白、血小板、估算肾小球滤过率（eGFR）、D-二聚体、C 反应蛋白和中性粒细胞与淋巴细胞比值（后三者取对数）、出血风险评分、抗血小板药物使用、研究中心和入组年份。支架置入、术后溶解程度和出院抗凝方案属于暴露与结局之间的中介变量，调整后会阻断部分因果路径，故未作为协变量；失访与 PTS 评估缺失可能同时受基线因素和治疗影响，以 IPCW 处理（附图 S1）。本数据集中基线变量无缺失。")
h2("2.6 统计分析")
p("连续变量以均数 ± 标准差或中位数（四分位数间距）表示，分类变量以例数（%）表示；以标准化均数差（standardized mean difference，SMD）评价加权前后的平衡，|SMD| <0.1 视为平衡良好^[27]^，并报告有效样本量（ESS）。")
p("**主分析（ITT 类比）**：在 CCW 加权数据中，以考虑时间依赖性权重的加权 Aalen–Johansen 法估计各结局累积发生率，死亡作为竞争风险^[28]^，报告 12 和 24 个月的绝对风险差（RD）和风险比（RR）。由于克隆设计中风险比在宽限期内不满足比例假定，未以 HR 作为主要效应量。win ratio 采用 IPCW 校正的广义配对比较^[17,18,29]^：每一配对的胜/负以双方在判定时刻的权重乘积加权，因删失而无法判定的配对不计入胜负；同时报告 win odds（计入平局）^[30]^ 与净获益（net benefit）^[18]^，以及各层的胜负比例。所有 95% 置信区间（CI）由按中心分层、以患者（而非克隆）为单位重抽样并在每次重抽样中重新估计全部权重的非参数 bootstrap 获得（主分析 1000 次，敏感性与亚组分析 500 次，风险分层分析 300 次），比值类指标在对数尺度上取百分位区间，P 值由 bootstrap 标准误的 Wald 检验获得。")
p("**补充分析（地标设计）**：以宽限期末（第 7 天）为地标，排除此前已发生死亡、复发 VTE、大出血或失访者，按此前是否介入分组，分别以重叠权重（overlap weights）^[31]^和截尾逆概率处理权重（IPTW）重新估计上述指标；对 24 个月累积中重度 PTS 和任意 PTS 另以增强逆概率加权（AIPW）双稳健估计^[32]^，同时以 logistic 模型校正结局缺失。为减少参数模型设定错误的影响，又以 SuperLearner 交叉拟合 AIPW 重新估计 24 个月中重度 PTS、任意 PTS 和大出血^[@sl,@dml]^：倾向评分、结局缺失概率和结局回归均由 SuperLearner 拟合，候选算法包括均值模型、logistic 回归、L1 惩罚 logistic 回归、样条 logistic 回归（类 GAM）、随机森林和梯度提升树，以 5 折交叉验证的对数损失确定非负凸组合权重；采用 5 折交叉拟合（cross-fitting），倾向评分截尾于 [0.01, 0.99]，以影响函数计算标准误，并以 5 次不同随机划分的中位数合并结果。")
p("**敏感性分析**（均预先设定）：S1 宽限期改为 3 天和 5 天（数据中无确诊 7 天后的首次介入，故 14 天宽限期与主分析相同）；S2 PP 类比，策略 B 中随访期间任何救治性介入即删失并以时间依赖 IPCW 校正；S3 地标设计（见上）；S4 仅以 PMT（含 CDT+PMT 联合）作为策略 A，排除单纯 CDT 病例；S5 排除 2016—2018 年病例；S7 结局缺失的完整病例分析与临界点（tipping point）分析；S8 改变 win ratio 层级顺序（大出血前置、中重度 PTS 前置、增加 CRNMB 层）；S9 权重截尾于第 95、99.5 百分位或不截尾；S10 不校正失访。原计划的 S6（仅使用门诊标准 Villalta 评分）因数据集未区分评估方式而未能实施。")
p("**未测量混杂的评估**：计算中重度 PTS 和大出血 RR 及其 CI 界限的 E 值^[33]^，并与已测量混杂因素中与治疗和结局关联最强者比较（基准化）；结合阴性对照结局判断残余混杂^[26]^。")
p("**疗效异质性**：预设亚组为症状 ≤7 天 vs 8～14 天、髂静脉受累与否、年龄 <50 岁 vs ≥50 岁、合并髂静脉压迫综合征与否；每个亚组内重新估计权重，交互作用 P 值由两亚组 bootstrap 估计差值的 Wald 检验获得。参照 PATH 声明^[34]^，在全队列中以全部基线协变量及治疗项拟合 24 个月中重度 PTS 的 logistic 风险模型，以“单纯抗凝”情境下的预测风险将患者三等分，分别报告各风险层的中重度 PTS 与大出血绝对风险差。")
p("**探索性因果森林**：在地标数据中以因果森林估计 24 个月中重度 PTS 的个体化处理效应（CATE）^[@wa,@grf]^，用于发现预设亚组以外的效应修饰。森林采用诚实（honest）分裂、2000 棵树、最小叶节点 10，结局与处理的干扰函数以梯度提升树交叉拟合，并以结局可观察概率的倒数加权校正缺失；以 5 折样本外预测得到每例患者的 CATE。异质性评价包括：①校准检验（以 SuperLearner 双稳健得分对平均预测和差异化预测回归，等价于 grf 的 test_calibration）；②以预测获益排序的秩加权平均处理效应（RATE，含 AUTOC 和 Qini 系数）^[@rate]^，标准误由 1000 次 bootstrap 估计；③按预测 CATE 三分位分组的双稳健效应估计；④双稳健得分对主要候选效应修饰因素的最佳线性投影。该分析为假设生成性。")
p("双侧 P <0.05 为差异有统计学意义；亚组与敏感性分析视为探索性，未作多重比较校正。分析使用 Python 3.13（numpy、pandas、scipy、scikit-learn 1.9 及 EconML 0.17），CCW 权重、加权 Aalen–Johansen 估计和 IPCW 校正 win ratio 均为自编代码【代码公开地址待填】。")

# =========================================================== RESULTS
h1("3 结果")
h2("3.1 研究人群与治疗")
yr = T["year_rate"]["mean"]; cr_ = T["center_rate"]["mean"]
p(f"共纳入 {N} 例患者，年龄 {d.age.mean():.1f} ± {d.age.std():.1f} 岁，女性 {int(d.female.sum())} 例（{pp(d.female.mean())}%），髂静脉受累 {int(d.iliac.sum())} 例（{pp(d.iliac.mean())}%），症状持续时间中位 {d.symdur.median():.0f}（{d.symdur.quantile(.25):.0f}～{d.symdur.quantile(.75):.0f}）天。{nA} 例（{pp(nA/N)}%）在确诊后 7 天内接受血栓清除，中位第 {day_med:.0f}（{day_q[0]:.0f}～{day_q[1]:.0f}）天，第 90 百分位为第 {T['day_p90']:.0f} 天，{pp(T['within72'])}% 在 3 天内完成；其中单纯 CDT {mt[1]} 例、PMT {mt[2]} 例、CDT+PMT 联合 {mt[3]} 例，同期髂静脉支架置入 {T['stent']} 例（{pp(T['stent']/nA)}%）。其余 {nB} 例接受单纯抗凝。各中心早期介入比例为 {pp(min(cr_.values()))}%～{pp(max(cr_.values()))}%，各年度为 {pp(min(yr.values()))}%～{pp(max(yr.values()))}%（图 1）。")
p(f"中位随访 {F['median_fu']:.0f} 天；24 个月内死亡 {F['deaths']} 例，失访 {F['ltfu']} 例（早期清除组 {F['ltfu_A']} 例，单纯抗凝组 {F['ltfu_B']} 例）；6、12、18、24 个月完成 Villalta 评估者分别为 {F['visits'][6]}、{F['visits'][12]}、{F['visits'][18]}、{F['visits'][24]} 例。宽限期内仅发生 2 例结局事件：1 例未介入患者第 5 天复发 DVT（计入两臂），1 例第 3 天介入患者第 6 天发生 CRNMB。")
img("fig/fig1.png", 2016 / 2401, 560)
cap("**图 1** 研究流程与克隆—删失—加权设计示意。A：患者流程；B：三种典型情形下两份克隆的随访、删失与事件计入方式")

h2("3.2 基线特征与加权平衡")
p(f"加权前，早期清除组患者更年轻、血栓范围更广、症状持续时间更短、疼痛评分更高、髂静脉压迫综合征比例更高，既往脑卒中比例和出血风险评分更低，{n_imb} 个协变量 |SMD| >0.1（最大 {mx_c:.2f}）。CCW 加权后所有协变量 |SMD| 均 <0.1（最大 {mx_w:.2f}）（表 2，附图 S2）。7 天内介入的预测概率范围为 {W['pA'][0]:.2f}～{W['pA'][4]:.2f}，无 <0.05 或 >0.95 的极端值，两组分布充分重叠（附图 S3）。截尾后稳定化权重均值分别为 {W['stab_A'][0]:.2f}（{W['stab_A'][1]:.2f}～{W['stab_A'][2]:.2f}）和 {W['stab_B'][0]:.2f}（{W['stab_B'][1]:.2f}～{W['stab_B'][2]:.2f}），有效样本量分别为 {W['ess_A']:.0f} 和 {W['ess_B']:.0f}；失访权重最大值为 {max(W['ltfu_A'][1], W['ltfu_B'][1]):.2f}。")
cap(f"**表 2** 按宽限期内实际治疗分组的基线特征及加权前后标准化均数差")
rows = []
for _, r in tb.iterrows():
    def fmt(s):
        return s.replace("–", "～")
    lab = r.label
    rows.append([lab, fmt(r["all"]), fmt(r.A), fmt(r.B), f"{r.smd_crude:.2f}", f"{r.smd_w:.2f}"])
# nicer number formatting for D-dimer/CRP/NLR medians
def med(col, k=2):
    def f(s): return f"{s.median():.{k}f}（{s.quantile(.25):.{k}f}～{s.quantile(.75):.{k}f}）"
    return f(d[col]), f(d[d.trt == 1][col]), f(d[d.trt == 0][col])
for i, row in enumerate(rows):
    key = tb.iloc[i]["var"]
    if key in ("dd", "nlr"): row[1:4] = med(key, 2)
    if key == "crp": row[1:4] = med(key, 1)
tab(["变量", f"全部（n = {N}）", f"早期血栓清除（n = {nA}）", f"单纯抗凝（n = {nB}）", "SMD 加权前", "SMD 加权后"], rows,
    widths=[0.24, 0.17, 0.17, 0.17, 0.125, 0.125])
note("数据以均数 ± 标准差、中位数（四分位数间距）或例数（%）表示。SMD：标准化均数差，加权后为 CCW 治疗删失权重加权。中心 1 为参照。BMI：体质指数；eGFR：估算肾小球滤过率；NLR：中性粒细胞与淋巴细胞比值。")

h2("3.3 主要结局：分层复合结局")
p(f"全部加权配对中，早期血栓清除“胜”的比例为 {pc(M['pW'][0])}，“负”为 {pc(M['pL'][0])}，平局为 {pc(M['pT'][0])}。win ratio 为 {wrci(wr)}，P = {P(wr[3])}；win odds 为 {wo[0]:.2f}（{wo[1]:.2f}–{wo[2]:.2f}），净获益为 {sg(nb[0])}%（{sg(nb[1])}% 至 {sg(nb[2])}%）。分层看，胜负主要由第 4 层中重度 PTS（胜 {pc(M['tier_ms_W'][0])} vs 负 {pc(M['tier_ms_L'][0])}）和第 5 层任意 PTS（{pc(M['tier_any_W'][0])} vs {pc(M['tier_any_L'][0])}）驱动，而第 3 层大出血明显偏向单纯抗凝（{pc(M['tier_mb_W'][0])} vs {pc(M['tier_mb_L'][0])}）；死亡层和复发 VTE 层胜负接近（图 2）。")
img("fig/fig2.png", 999 / 2139, 600)
cap("**图 2** 24 个月分层复合结局各层的加权胜/负比例。各层比例以全部加权配对为分母，未在该层之前判定的配对方进入该层比较")

h2("3.4 次要结局")
p(f"早期血栓清除组 24 个月中重度 PTS 累积发生率为 {pc(M['ms_730_A'][0])}，单纯抗凝组为 {pc(M['ms_730_B'][0])}，RD 为 {sg(ms[0])}%（95% CI {sg(ms[1])}% 至 {sg(ms[2])}%），RR 为 {rrci(M['ms_730_RR'])}；12 个月时差异尚未达统计学意义（RD {sg(M['ms_365_RD'][0])}%，95% CI {sg(M['ms_365_RD'][1])}% 至 {sg(M['ms_365_RD'][2])}%）。任意 PTS 24 个月累积发生率分别为 {pc(M['any_730_A'][0])} 和 {pc(M['any_730_B'][0])}（RD {sg(M['any_730_RD'][0])}%，95% CI {sg(M['any_730_RD'][1])}% 至 {sg(M['any_730_RD'][2])}%）。大出血 24 个月累积发生率分别为 {pc(M['mb_730_A'][0])} 和 {pc(M['mb_730_B'][0])}（RD {sg(mb[0])}%，95% CI {sg(mb[1])}% 至 {sg(mb[2])}%；RR {rrci(M['mb_730_RR'])}）。全队列 10 天内无大出血事件；早期清除组 {cr['mb'][0]} 例大出血最早发生于确诊后第 47 天，90 天内两组各 3 例，超额风险主要出现在 3 个月以后（图 3）。CRNMB、复发 VTE、全因死亡和再次介入的差异均无统计学意义（表 3）。按此估计，每治疗约 {NNT:.0f} 例可减少 1 例中重度 PTS，每治疗约 {NNH:.0f} 例增加 1 例大出血。")
cap("**表 3** 12 和 24 个月加权累积发生率（死亡为竞争风险）")
names = [("ms", "中重度 PTS"), ("any", "任意 PTS"), ("mb", "ISTH 大出血"), ("crnmb", "CRNMB"), ("vte", "复发 VTE"), ("death", "全因死亡"), ("reint", "再次静脉介入"), ("nc", "阴性对照：感染性住院")]
rows = []
for k, lab in names:
    rows.append([lab, pc(M[f"{k}_365_A"][0]), pc(M[f"{k}_365_B"][0]), pc(M[f"{k}_730_A"][0]), pc(M[f"{k}_730_B"][0]),
                 rdci(M[f"{k}_730_RD"]), rrci(M[f"{k}_730_RR"]), P(M[f"{k}_730_RD"][3])])
tab(["结局", "12 个月 A", "12 个月 B", "24 个月 A", "24 个月 B", "24 个月 RD，%（95% CI）", "24 个月 RR（95% CI）", "P"], rows,
    widths=[0.17, 0.09, 0.09, 0.09, 0.09, 0.21, 0.17, 0.09])
note(f"A：早期血栓清除；B：单纯抗凝。RD：风险差（百分点）；RR：风险比。全因死亡未设竞争风险。粗事件数（A/B）：中重度 PTS {cr['ms'][0]}/{cr['ms'][1]}，任意 PTS {cr['any'][0]}/{cr['any'][1]}，大出血 {cr['mb'][0]}/{cr['mb'][1]}，CRNMB {cr['crnmb'][0]}/{cr['crnmb'][1]}，复发 VTE {cr['vte'][0]}/{cr['vte'][1]}，死亡 {cr['death'][0]}/{cr['death'][1]}，再次介入 {cr['reint'][0]}/{cr['reint'][1]}，感染性住院 {cr['nc'][0]}/{cr['nc'][1]}。")
img("fig/fig3.png", 1719 / 2129, 580)
cap("**图 3** 加权累积发生率曲线。A：中重度 PTS；B：任意 PTS；C：ISTH 大出血；D：复发 VTE。PTS 仅在 6、12、18、24 个月访视时评估，故呈阶梯状")

v24 = CS[(24, "villalta")]; q24 = CS[(24, "qol")]; pat24 = CS[(24, "patent")]; pat12 = CS[(12, "patent")]
it = D["items24"]
p(f"在各随访时点，早期清除组 Villalta 总分均较低，24 个月加权均值分别为 {v24['m1']:.1f} 和 {v24['m0']:.1f} 分（差值 {v24['diff']:.1f}，95% CI {v24['lo']:.1f} 至 {v24['hi']:.1f}），其中症状项差值 {it['sym']['diff']:.1f} 分、体征项差值 {it['sig']['diff']:.1f} 分；24 个月时点中重度 PTS 现患率分别为 {pc(CS[(24,'msp')]['m1'])} 和 {pc(CS[(24,'msp')]['m0'])}。VEINES-QOL 评分 24 个月差值为 {q24['diff']:.1f} 分（95% CI {q24['lo']:.1f} 至 {q24['hi']:.1f}），绝对差异较小。静脉通畅率 12 个月分别为 {pc(pat12['m1'])} 和 {pc(pat12['m0'])}，24 个月为 {pc(pat24['m1'])} 和 {pc(pat24['m0'])}（附图 S4）。")

h2("3.5 敏感性分析")
def srow(lab, r, has_wr=True):
    return [lab, wrci(r["WR"]).replace("95% CI ", "") if has_wr and "WR" in r else "—",
            rdci(r["ms_730_RD"]) if "ms_730_RD" in r else "—", rdci(r["mb_730_RD"]) if "mb_730_RD" in r else "—"]
rows = [srow("主分析（CCW，ITT 类比，宽限期 7 天）", M),
        srow("S1 宽限期 3 天", S["S1_grace3"]), srow("S1 宽限期 5 天", S["S1_grace5"]),
        srow("S2 符合方案类比", S["S2_pp"]),
        srow("S3 地标设计 + 重叠权重", S["S3_overlap"]), srow("S3 地标设计 + IPTW", S["S3_iptw"]),
        ["S3 地标设计 + AIPW（24 个月累积）", "—", rdci((S["S3_aipw_ms"]["RD"])), "—"],
        ["S3 地标设计 + SuperLearner AIPW", "—", rdci(SL["ms"]["rd"]), rdci(SL["mb"]["rd"])],
        srow("S4 仅 PMT（排除单纯 CDT）", S["S4_pmt"]), srow("S5 排除 2016—2018 年病例", S["S5_2019on"]),
        srow("S8 大出血层前置于复发 VTE", S["S8_bleedfirst"]), srow("S8 中重度 PTS 层前置于复发 VTE", S["S8_ptsfirst"]),
        srow("S8 增加 CRNMB 层", S["S8_crnmb"]),
        srow("S9 权重截尾于 P95", S["S9_t95"]), srow("S9 权重截尾于 P99.5", S["S9_t995"]), srow("S9 不截尾", S["S9_none"]),
        srow("S10 不校正失访", S["S10_noltfu"])]
s3 = S["S3_overlap"]; g3 = S["S1_grace3"]; g5 = S["S1_grace5"]
tp = H["tipping"]
s5 = S["S5_2019on"]; s8p = S["S8_ptsfirst"]; s8c = S["S8_crnmb"]; s8b = S["S8_bleedfirst"]
p(f"在 PP 类比、地标设计、仅 PMT、不同权重截尾和不校正失访等分析中，中重度 PTS 风险降低和大出血风险增加的方向与幅度均与主分析一致，win ratio 点估计介于 {min(S[k]['WR'][0] for k in ['S2_pp','S3_overlap','S3_iptw','S4_pmt','S9_t95','S9_t995','S9_none','S10_noltfu']):.2f}～{max(S[k]['WR'][0] for k in ['S2_pp','S3_overlap','S3_iptw','S4_pmt','S9_t95','S9_t995','S9_none','S10_noltfu']):.2f}，95% CI 均跨越 1（表 4，图 4）。地标设计下重叠权重估计的 win ratio 为 {s3['WR'][0]:.2f}（{s3['WR'][1]:.2f}–{s3['WR'][2]:.2f}），AIPW 估计的 24 个月中重度 PTS RD 为 {sg(S['S3_aipw_ms']['RD'][0])}%（{sg(S['S3_aipw_ms']['RD'][1])}% 至 {sg(S['S3_aipw_ms']['RD'][2])}%），任意 PTS 为 {sg(S['S3_aipw_any']['RD'][0])}%（{sg(S['S3_aipw_any']['RD'][1])}% 至 {sg(S['S3_aipw_any']['RD'][2])}%）。SuperLearner 交叉拟合 AIPW 得到的 24 个月中重度 PTS RD 为 {sg(SL['ms']['rd'][0])}%（{sg(SL['ms']['rd'][1])}% 至 {sg(SL['ms']['rd'][2])}%；RR {SL['ms']['rr'][0]:.2f}，{SL['ms']['rr'][1]:.2f}–{SL['ms']['rr'][2]:.2f}），任意 PTS 为 {sg(SL['any']['rd'][0])}%（{sg(SL['any']['rd'][1])}% 至 {sg(SL['any']['rd'][2])}%），大出血为 {sg(SL['mb']['rd'][0])}%（{sg(SL['mb']['rd'][1])}% 至 {sg(SL['mb']['rd'][2])}%），与主分析几乎相同；倾向评分与结局模型中随机森林、L1 惩罚 logistic 回归和 logistic 回归获得了主要权重（附表 S1）。值得注意的是，宽限期缩短为 3 天时 win ratio 降至 {g3['WR'][0]:.2f}（{g3['WR'][1]:.2f}–{g3['WR'][2]:.2f}），中重度 PTS RD 缩小为 {sg(g3['ms_730_RD'][0])}%（{sg(g3['ms_730_RD'][1])}% 至 {sg(g3['ms_730_RD'][2])}%），5 天时介于二者之间（win ratio {g5['WR'][0]:.2f}）。排除 2016—2018 年病例后，大出血超额风险减小（RD {sg(s5['mb_730_RD'][0])}%，95% CI {sg(s5['mb_730_RD'][1])}% 至 {sg(s5['mb_730_RD'][2])}%），win ratio 升至 {wrci(s5['WR'])}。win ratio 对层级设定较敏感：将中重度 PTS 层前置于复发 VTE 和大出血时，win ratio 为 {wrci(s8p['WR'])}，差异有统计学意义；大出血前置于复发 VTE 时为 {s8b['WR'][0]:.2f}（{s8b['WR'][1]:.2f}–{s8b['WR'][2]:.2f}）；增加 CRNMB 层后降至 {s8c['WR'][0]:.2f}（{s8c['WR'][1]:.2f}–{s8c['WR'][2]:.2f}）。")
p(f"临界点分析中，在结局可判定的患者中，IPTW 加权的 24 个月累积中重度 PTS 比例为 {pc(tp['cc'][0])} vs {pc(tp['cc'][1])}；早期清除组 {tp['nmiss_A']} 例和单纯抗凝组 {tp['nmiss_B']} 例结局不可判定。若假定单纯抗凝组缺失者按其观察比例发生中重度 PTS，则早期清除组缺失者中重度 PTS 发生比例需达到 ≥{tp['tip_rB0.414'][0]*100:.0f}% 时 95% CI 上限才跨越 0；即使假定单纯抗凝组缺失者全部未发生，该临界比例仍为 ≥{tp['tip_rB0.0'][0]*100:.0f}%。")
cap("**表 4** 敏感性分析")
tab(["分析", "Win ratio（95% CI）", "24 个月中重度 PTS RD，%（95% CI）", "24 个月大出血 RD，%（95% CI）"], rows, widths=[0.34, 0.2, 0.23, 0.23])
note("RD：早期血栓清除减单纯抗凝的风险差（百分点）。AIPW 估计以 24 个月累积二分类结局为对象。宽限期 14 天与主分析结果相同（数据中无确诊 7 天后的首次血栓清除）。")

h2("3.6 阴性对照结局与未测量混杂")
nc = M["nc_730_RR"]
p(f"阴性对照结局（24 个月感染性住院）加权累积发生率分别为 {pc(M['nc_730_A'][0])} 和 {pc(M['nc_730_B'][0])}，RR 为 {rrci(nc)}，差异无统计学意义，但点估计偏向早期清除组，提示可能存在一定程度的“健康使用者”型残余混杂。中重度 PTS RR 的 E 值为 {E_ms:.2f}（CI 上限对应 {E_ms_ci:.2f}），即未测量混杂因素需与治疗选择和中重度 PTS 均有至少 {E_ms:.2f} 倍的风险比关联，才能完全解释所观察到的效应；而已测量协变量中关联最强的“{bench_name}”与早期介入和中重度 PTS 的粗风险比仅分别为 {bench[1]:.2f} 和 {bench[2]:.2f}。大出血 RR 的 E 值为 {E_mb:.2f}（CI 下限对应 {E_mb_ci:.2f}）。")

h2("3.7 疗效异质性")
sub_pairs = [("症状持续时间", "symdur_le7", "≤7 天", "symdur_gt7", "8～14 天"), ("髂静脉受累", "iliac_yes", "是", "iliac_no", "否"),
             ("年龄", "age_lt50", "<50 岁", "age_ge50", "≥50 岁"), ("髂静脉压迫综合征", "mts_yes", "是", "mts_no", "否")]
rows = []
for name, a, la, b, lb in sub_pairs:
    pi_ms = inter(a, b, "ms_730_RD"); pi_mb = inter(a, b, "mb_730_RD"); pi_wr = inter(a, b, "WR")
    for k, (key, lab) in enumerate(((a, la), (b, lb))):
        r = SUB[key]["summ"]
        rows.append([f"{name}：{lab}" if k == 0 else f"  {lab}", f"{SUB[key]['nA']}/{SUB[key]['n']-SUB[key]['nA']}",
                     rdci(r["ms_730_RD"]), rdci(r["mb_730_RD"]), wrci(r["WR"]).replace("95% CI ", ""),
                     f"{P(pi_ms)} / {P(pi_mb)} / {P(pi_wr)}" if k == 0 else ""])
labs = ["低", "中", "高"]
for g in range(3):
    r = H[f"risk{g}"]["summ"]; info = H[f"risk{g}"]
    rows.append([f"PTS 基线风险：{labs[g]}（预测 {info['pred'][0]*100:.0f}%）" if g == 0 else f"  {labs[g]}（预测 {info['pred'][0]*100:.0f}%）",
                 f"{info['nA']}/{info['n']-info['nA']}", rdci(r["ms_730_RD"]), rdci(r["mb_730_RD"]), wrci(r["WR"]).replace("95% CI ", ""), ""])
SR = {k: SUB[k]["summ"] for k in SUB}
il = d[d.iliac == 0]
p(f"预设亚组的交互作用检验均未达统计学意义（表 5，图 4）。髂静脉受累者（{SUB['iliac_yes']['n']} 例）中重度 PTS RD 为 {sg(SR['iliac_yes']['ms_730_RD'][0])}%（{sg(SR['iliac_yes']['ms_730_RD'][1])}% 至 {sg(SR['iliac_yes']['ms_730_RD'][2])}%），win ratio 为 {wrci(SR['iliac_yes']['WR'])}；而无髂静脉受累者仅 {SUB['iliac_no']['n']} 例（介入 {SUB['iliac_no']['nA']} 例），粗中重度 PTS 比例为 {il[il.trt==1].ms_t.notna().mean()*100:.1f}% vs {il[il.trt==0].ms_t.notna().mean()*100:.1f}%，介入组 {int(il[il.trt==1].mb.sum())} 例大出血而抗凝组为 0，加权估计极不稳定（交互 P：中重度 PTS {P(inter('iliac_yes','iliac_no','ms_730_RD'))}，win ratio {P(inter('iliac_yes','iliac_no','WR'))}）。与预设假设相反，年龄 ≥50 岁者 win ratio（{SR['age_ge50']['WR'][0]:.2f}，{SR['age_ge50']['WR'][1]:.2f}–{SR['age_ge50']['WR'][2]:.2f}）高于 <50 岁者（{SR['age_lt50']['WR'][0]:.2f}，{SR['age_lt50']['WR'][1]:.2f}–{SR['age_lt50']['WR'][2]:.2f}；交互 P = {P(inter('age_lt50','age_ge50','WR'))}），主要由于年轻患者 PTS 获益较小。症状持续时间与髂静脉压迫综合征亚组间差异不明显。基于风险的分析中，PTS 风险模型经 bootstrap 校正的 C 统计量为 {H['risk_model']['auc_opt']:.2f}；低、中、高风险层中重度 PTS 的绝对风险降低相近（RD 分别为 {sg(H['risk0']['summ']['ms_730_RD'][0])}%、{sg(H['risk1']['summ']['ms_730_RD'][0])}% 和 {sg(H['risk2']['summ']['ms_730_RD'][0])}%），而大出血超额风险集中于低风险层（{sg(H['risk0']['summ']['mb_730_RD'][0])}%，95% CI {sg(H['risk0']['summ']['mb_730_RD'][1])}% 至 {sg(H['risk0']['summ']['mb_730_RD'][2])}%），中、高风险层分别为 {sg(H['risk1']['summ']['mb_730_RD'][0])}% 和 {sg(H['risk2']['summ']['mb_730_RD'][0])}%，因此 win ratio 点估计随基线 PTS 风险升高而增大（{H['risk0']['summ']['WR'][0]:.2f}、{H['risk1']['summ']['WR'][0]:.2f}、{H['risk2']['summ']['WR'][0]:.2f}），但各层 CI 均较宽。")
cd = SL["cate_dist"]; cal = SL["calib"]; ra = SL["rate"]; gt = SL["gates"]; blp = dict((b[0], b[1:]) for b in SL["blp"])
p(f"探索性因果森林估计的平均效应为 {sg(SL['cf_ate'][0])}%（{sg(SL['cf_ate'][1])}% 至 {sg(SL['cf_ate'][2])}%）。样本外 CATE 中位数为 {sg(cd[1][2])}%，第 5～95 百分位为 {sg(cd[1][0])}% 至 {sg(cd[1][4])}%，{pc(cd[2])} 的患者预测获益（附图 S5A）。校准检验中平均预测系数为 {cal['mean_coef'][0]:.2f}（P = {P(cal['mean_coef'][2])}），而差异化预测系数为 {cal['diff_coef'][0]:.2f}（P = {P(cal['diff_coef'][2])}）；按预测获益排序的 AUTOC 为 {sg(ra['autoc'][0])}%（SE {ra['autoc'][1]*100:.1f}，P = {P(ra['autoc'][2])}），Qini 系数 P = {P(ra['qini'][2])}。按预测 CATE 三分位分组的双稳健 RD 分别为 {sg(gt[0][3])}%、{sg(gt[1][3])}% 和 {sg(gt[2][3])}%，未呈单调趋势（附图 S5B–C）。上述结果均未提示可被可靠识别的效应异质性。最佳线性投影中，髂静脉受累与更大的中重度 PTS 风险降低相关（系数 {blp['iliac'][0]*100:.1f} 个百分点，P = {P(blp['iliac'][2])}），出血风险评分每增加 1 分获益减少 {blp['bleedscore'][0]*100:.1f} 个百分点（P = {P(blp['bleedscore'][2])}），其余候选因素无明显关联（附表 S2）。")
cap("**表 5** 预设亚组与基于风险的疗效异质性")
tab(["亚组", "n（A/B）", "中重度 PTS RD，%（95% CI）", "大出血 RD，%（95% CI）", "Win ratio（95% CI）", "交互 P（PTS/出血/WR）"], rows,
    widths=[0.21, 0.1, 0.19, 0.18, 0.17, 0.15])
note("每个亚组/风险层内重新估计权重。基于风险的分层以“单纯抗凝”情境下预测的 24 个月中重度 PTS 风险三等分（PATH 声明），括号内为该层平均预测风险。")
img("fig/fig4.png", 0.62, 600)
cap("**图 4** 敏感性分析与亚组分析森林图。A：24 个月中重度 PTS 风险差；B：24 个月大出血风险差；C：win ratio（对数尺度）")

# =========================================================== DISCUSSION
h1("4 讨论")
p(f"本研究基于 4 家中心 {N} 例急性髂股 DVT 患者的真实世界数据，采用 CCW 框架模拟目标试验，得到三点主要发现。第一，确诊后 7 天内血栓清除使 24 个月中重度 PTS 的绝对风险降低约 11 个百分点，任意 PTS 降低约 9 个百分点，Villalta 评分、静脉通畅率亦有改善；第二，这一获益伴随约 5 个百分点的大出血绝对风险增加，且超额出血并非集中于围术期；第三，在同时纳入死亡、复发 VTE、出血和 PTS 的分层复合结局上，win ratio 为 {wr[0]:.2f}，95% CI 跨越 1，即总体净临床获益未达统计学意义。PTS 获益与出血增加在地标设计、重叠权重、双稳健估计及多种权重设定下保持一致，而复合结局的结论对层级顺序和研究年代较为敏感。")
h2("4.1 与既往 RCT 的比较")
p("本研究中重度 PTS 的相对风险降低（RR 约 0.72）与 ATTRACT 试验（18% vs 24%）及其髂股亚组（18% vs 28%）的结果方向和幅度相近^[5,6]^。与 ATTRACT 不同的是，本研究同时观察到任意 PTS 的降低，这与 CaVenT 试验更为接近^[3,4]^。可能的解释包括：本研究人群全部为髂股 DVT，且 84% 累及髂静脉、40% 合并髂静脉压迫综合征，流出道梗阻负荷更重；PMT 构成比例高，约 38% 的介入患者同期置入髂静脉支架，而支架可纠正潜在的流出道梗阻^[35]^；此外，本研究以 6～24 个月内任一次评估达标定义累积 PTS，与 ATTRACT 一致，但 Villalta 评估部分依赖电话随访，可能存在测量差异。CAVA 试验未显示显著获益，可能与其超声加速 CDT 技术、较低的支架率及 12 个月的较短随访有关^[7]^。总体而言，本研究支持“血栓清除对 PTS 严重程度的作用强于对 PTS 发生本身的作用”这一观点^[5,6,8]^。")
p(f"在安全性方面，ATTRACT 中大出血增加集中于术后 10 天内（1.7% vs 0.3%）^[5]^，美国全国住院样本研究亦显示 CDT 与住院期间出血和颅内出血增加相关^[36]^。而本研究 10 天内无大出血事件，介入组大出血最早发生于第 47 天，90 天内两组相当，超额风险主要出现在 3 个月以后。这提示超额出血更可能与介入后的长期抗栓管理（如支架术后抗凝联合抗血小板治疗、抗凝疗程延长或强度增加）相关，而非溶栓操作本身；但本数据集未记录出院抗栓方案，也不能排除介入组随访更密切导致的检出偏倚。这一发现具有直接的临床含义：优化介入后抗栓方案可能是改善血栓清除净获益的关键环节，值得在后续研究中专门评估。")
h2("4.2 方法学考量")
p("既往比较血栓清除与抗凝的观察性研究多按“最终是否接受介入”分组，从而受不朽时间偏倚影响^[12,13,36]^。本研究以确诊日为零时点、以 7 天宽限期定义“早期”策略，并通过 CCW 使两臂在零时点完全可比，宽限期内的事件同时计入两臂^[13–15]^。加权后协变量平衡良好、倾向概率分布充分重叠、权重分布温和，主分析与地标设计、AIPW 结果高度一致，说明结论对分析框架的选择不敏感。")
p(f"宽限期敏感性分析值得重视：将“早期”定义为 3 天内时，中重度 PTS 的获益缩小、win ratio 接近 1。这一结果与“越早清除越好”的直觉相反。描述性比较显示，3 天内与第 4～7 天介入者的血栓范围评分（均为 3.6）、疼痛评分和腿围差等已测量特征相近，但后者中重度 PTS 粗发生率较低（21.2% vs 31.9%）。这可能反映未测量的选择因素（如更充分的术前影像评估、血栓性质差异），也可能提示短期抗凝后再行介入并不劣于立即介入；亦不排除样本量减少带来的随机波动。由于宽限期改变的是所比较的治疗策略本身，该结果并不否定主分析，但提示“早期”的具体时间窗仍需前瞻性研究界定。")
p(f"win ratio 的优势在于按临床优先级同时比较疗效与安全性^[17–19]^。本研究中约 {pc(M['pT'][0],0)} 的配对为平局，胜负主要由 PTS 层决定，而出血层抵消了相当一部分获益。敏感性分析显示，结论对层级顺序敏感：若将中重度 PTS 置于复发 VTE 和大出血之前，win ratio 达到统计学意义（{S['S8_ptsfirst']['WR'][0]:.2f}），若再纳入 CRNMB 则进一步接近 1。本研究预先设定的层级遵循“严重性越高越优先”的原则，将可致命或需住院的大出血置于慢性 PTS 之前；对更重视长期肢体功能的患者而言，获益—风险的权衡可能不同。此外，排除 2016—2018 年病例后出血超额风险减小、win ratio 达到统计学意义，提示随着技术与围术期管理的成熟，净获益可能有所改善，但这一时期效应需独立验证。还应注意，win ratio 将一次大出血与一次中重度 PTS 视为不同优先级的“一次失败”，并不反映二者的持续时间和严重程度差异；读者应结合各成分的绝对风险差（每治疗约 {NNT:.0f} 例减少 1 例中重度 PTS，代价是每治疗约 {NNH:.0f} 例增加 1 例大出血）作出判断。")
h2("4.3 谁更可能获益")
p("预设亚组中未发现统计学意义上的效应修饰，但本研究的亚组样本量有限，交互作用检验效能不足。累及髂静脉者获益更明确、而仅累及股总静脉者未见获益，这一方向与 ATTRACT 髂股及股腘亚组的结果一致^[2,6]^，支持将血栓清除优先用于髂静脉受累者；年轻患者获益较小这一与预设假设相反的发现，可能与其基线 PTS 风险较低有关，需谨慎解释。基于风险的分析显示，PTS 绝对风险降低在各风险层相近，而大出血超额风险集中于预测 PTS 风险较低的人群，使得 win ratio 点估计随基线 PTS 风险升高而增大。按照 PATH 声明的思路^[34]^，这提示血栓负荷重、症状重、预测 PTS 风险高的患者可能从血栓清除中获得更有利的获益—风险比，而 PTS 风险较低者接受介入的净获益更不确定。但上述分层结果的置信区间较宽，且低风险层出血事件数少，应视为假设生成性结论。探索性因果森林未发现可被可靠识别的总体效应异质性（校准检验和 RATE 均无统计学意义），但其最佳线性投影再次提示髂静脉受累是最可能的效应修饰因素，与亚组分析方向一致；在本研究的样本量下，机器学习方法更适合作为假设生成工具，而非用于个体化治疗决策。")
h2("4.4 局限性")
p("本研究存在以下局限。第一，作为观察性研究，因果推断依赖“无未测量混杂”假定。医生对患者耐受性的判断、患者意愿与支付能力、民族、医保类型、是否置入下腔静脉滤器及初始抗凝药物类型等变量未能获得；阴性对照结局点估计偏向介入组，提示可能存在一定的健康使用者偏倚，可能使 PTS 获益被高估。不过 E 值分析显示，需要相当强的未测量混杂才能完全解释中重度 PTS 的效应。第二，PTS 评估部分来自电话随访的患者报告版 Villalta 评分，数据集中未标注评估方式，预设的 S6 敏感性分析无法实施；评估者虽不知晓分组，但患者本人知晓治疗，主观症状评分可能受期望效应影响。第三，出院后抗凝/抗血小板方案及依从性、压力治疗等未记录，无法解释超额出血的机制。第四，PTS 仅在 6 个月间隔的访视中评估，属区间删失数据，本研究以首次检出时间近似处理。第五，部分亚组样本量较小，异质性分析（包括因果森林）效能有限；另外，本研究为 4 家中心的数据，结论向其他医疗环境的外推需谨慎。最后，目标试验模拟不能替代 RCT，其价值在于在新 RCT 难以实施时，以透明、可检验的方式提供最佳可得证据。")

h1("5 结论")
p(f"在真实世界急性髂股 DVT 患者中，确诊后 7 天内血栓清除联合抗凝较单纯抗凝可降低 24 个月中重度 PTS 和任意 PTS 风险，并改善静脉通畅和症状评分，但大出血风险增加，且增加主要发生在介入后数月。在综合死亡、复发 VTE、大出血和 PTS 的分层复合结局上，净临床获益未达统计学意义。临床决策应以个体 PTS 风险与出血风险的权衡为基础，并重视介入后的长期抗栓管理；介入时机与介入后抗栓策略的优化值得前瞻性研究进一步验证。")

h1("声明")
p("**伦理批准** 本研究经【各中心伦理委员会名称】批准（批件号【待填】），因回顾性设计豁免书面知情同意；电话随访获得口头知情同意。", noindent=True)
p("**研究注册** 【注册平台及注册号，待填】。", noindent=True)
p("**利益冲突** 所有作者声明无利益冲突【待确认】。", noindent=True)
p("**基金资助** 【待填】。", noindent=True)
p("**作者贡献** 【待填】。", noindent=True)
p("**数据可及性** 去标识化数据和分析代码可在合理请求下向通信作者获取【或填写公开地址】。", noindent=True)

# =========================================================== REFERENCES
h1("参考文献")
refs = [
 "Kahn SR, Shrier I, Julian JA, et al. Determinants and time course of the postthrombotic syndrome after acute deep venous thrombosis. Ann Intern Med, 2008, 149(10): 698-707. DOI: 10.7326/0003-4819-149-10-200811180-00004.",
 "Kearon C, Gu CS, Julian JA, et al. Pharmacomechanical catheter-directed thrombolysis in acute femoral-popliteal deep vein thrombosis: analysis from a stratified randomized trial. Thromb Haemost, 2019, 119(4): 633-644. DOI: 10.1055/s-0039-1677795.",
 "Enden T, Haig Y, Kløw NE, et al. Long-term outcome after additional catheter-directed thrombolysis versus standard treatment for acute iliofemoral deep vein thrombosis (the CaVenT study): a randomised controlled trial. Lancet, 2012, 379(9810): 31-38. DOI: 10.1016/S0140-6736(11)61753-4.",
 "Haig Y, Enden T, Grøtta O, et al. Post-thrombotic syndrome after catheter-directed thrombolysis for deep vein thrombosis (CaVenT): 5-year follow-up results of an open-label, randomised controlled trial. Lancet Haematol, 2016, 3(2): e64-e71. DOI: 10.1016/S2352-3026(15)00248-3.",
 "Vedantham S, Goldhaber SZ, Julian JA, et al. Pharmacomechanical catheter-directed thrombolysis for deep-vein thrombosis. N Engl J Med, 2017, 377(23): 2240-2252. DOI: 10.1056/NEJMoa1615066.",
 "Comerota AJ, Kearon C, Gu CS, et al. Endovascular thrombus removal for acute iliofemoral deep vein thrombosis: analysis from a stratified multicenter randomized trial. Circulation, 2019, 139(9): 1162-1173. DOI: 10.1161/CIRCULATIONAHA.118.037425.",
 "Notten P, ten Cate-Hoek AJ, Arnoldussen CWKP, et al. Ultrasound-accelerated catheter-directed thrombolysis versus anticoagulation for the prevention of post-thrombotic syndrome (CAVA): a single-blind, multicentre, randomised trial. Lancet Haematol, 2020, 7(1): e40-e49. DOI: 10.1016/S2352-3026(19)30209-1.",
 "Broderick C, Watson L, Armon MP. Thrombolytic strategies versus standard anticoagulation for acute deep vein thrombosis of the lower limb. Cochrane Database Syst Rev, 2021, 1(1): CD002783. DOI: 10.1002/14651858.CD002783.pub5.",
 "Kakkos SK, Gohel M, Baekgaard N, et al. Editor's Choice – European Society for Vascular Surgery (ESVS) 2021 clinical practice guidelines on the management of venous thrombosis. Eur J Vasc Endovasc Surg, 2021, 61(1): 9-82. DOI: 10.1016/j.ejvs.2020.09.023.",
 "Stevens SM, Woller SC, Baumann Kreuziger L, et al. Antithrombotic therapy for VTE disease: second update of the CHEST guideline and expert panel report. Chest, 2021, 160(6): e545-e608. DOI: 10.1016/j.chest.2021.07.055.",
 "中华医学会外科学分会血管外科学组. 深静脉血栓形成的诊断和治疗指南(第三版). 中国血管外科杂志(电子版), 2017, 9(4): 250-257.",
 "Hernán MA, Sauer BC, Hernández-Díaz S, et al. Specifying a target trial prevents immortal time bias and other self-inflicted injuries in observational analyses. J Clin Epidemiol, 2016, 79: 70-75. DOI: 10.1016/j.jclinepi.2016.04.014.",
 "Maringe C, Benitez Majano S, Exarchakou A, et al. Reflection on modern methods: trial emulation in the presence of immortal-time bias. Assessing the benefit of major surgery for elderly lung cancer patients using observational data. Int J Epidemiol, 2020, 49(5): 1719-1729. DOI: 10.1093/ije/dyaa057.",
 "Hernán MA, Robins JM. Using big data to emulate a target trial when a randomized trial is not available. Am J Epidemiol, 2016, 183(8): 758-764. DOI: 10.1093/aje/kwv254.",
 "Hernán MA. How to estimate the effect of treatment duration on survival outcomes using observational data. BMJ, 2018, 360: k182. DOI: 10.1136/bmj.k182.",
 "Cashin AG, Hansford HJ, Hernán MA, et al. Transparent reporting of observational studies emulating a target trial: the TARGET Statement. BMJ, 2025, 390: e087179. DOI: 10.1136/bmj-2025-087179.",
 "Pocock SJ, Ariti CA, Collier TJ, et al. The win ratio: a new approach to the analysis of composite endpoints in clinical trials based on clinical priorities. Eur Heart J, 2012, 33(2): 176-182. DOI: 10.1093/eurheartj/ehr352.",
 "Buyse M. Generalized pairwise comparisons of prioritized outcomes in the two-sample problem. Stat Med, 2010, 29(30): 3245-3257. DOI: 10.1002/sim.3923.",
 "Redfors B, Gregson J, Crowley A, et al. The win ratio approach for composite endpoints: practical guidance based on previous experience. Eur Heart J, 2020, 41(46): 4391-4399. DOI: 10.1093/eurheartj/ehaa665.",
 "Kang T, Lu YL, Han S, et al. Comparative outcomes of catheter-directed thrombolysis versus AngioJet pharmacomechanical catheter-directed thrombolysis for treatment of acute iliofemoral deep vein thrombosis. J Vasc Surg Venous Lymphat Disord, 2024, 12(1): 101669. DOI: 10.1016/j.jvsv.2023.08.010.",
 "Cole SR, Hernán MA. Constructing inverse probability weights for marginal structural models. Am J Epidemiol, 2008, 168(6): 656-664. DOI: 10.1093/aje/kwn164.",
 "Schulman S, Kearon C. Definition of major bleeding in clinical investigations of antihemostatic medicinal products in non-surgical patients. J Thromb Haemost, 2005, 3(4): 692-694. DOI: 10.1111/j.1538-7836.2005.01204.x.",
 "Kahn SR, Partsch H, Vedantham S, et al. Definition of post-thrombotic syndrome of the leg for use in clinical investigations: a recommendation for standardization. J Thromb Haemost, 2009, 7(5): 879-883. DOI: 10.1111/j.1538-7836.2009.03294.x.",
 "Kaatz S, Ahmad D, Spyropoulos AC, et al. Definition of clinically relevant non-major bleeding in studies of anticoagulants in atrial fibrillation and venous thromboembolic disease in non-surgical patients: communication from the SSC of the ISTH. J Thromb Haemost, 2015, 13(11): 2119-2126. DOI: 10.1111/jth.13140.",
 "Lamping DL, Schroter S, Kurz X, et al. Evaluation of outcomes in chronic venous disorders of the leg: development of a scientifically rigorous, patient-reported measure of symptoms and quality of life. J Vasc Surg, 2003, 37(2): 410-419. DOI: 10.1067/mva.2003.152.",
 "Lipsitch M, Tchetgen Tchetgen E, Cohen T. Negative controls: a tool for detecting confounding and bias in observational studies. Epidemiology, 2010, 21(3): 383-388. DOI: 10.1097/EDE.0b013e3181d61eeb.",
 "Austin PC. Balance diagnostics for comparing the distribution of baseline covariates between treatment groups in propensity-score matched samples. Stat Med, 2009, 28(25): 3083-3107. DOI: 10.1002/sim.3697.",
 "Aalen OO, Johansen S. An empirical transition matrix for non-homogeneous Markov chains based on censored observations. Scand J Stat, 1978, 5(3): 141-150.",
 "Dong G, Mao L, Huang B, et al. The inverse-probability-of-censoring weighting (IPCW) adjusted win ratio statistic: an unbiased estimator in the presence of independent censoring. J Biopharm Stat, 2020, 30(5): 882-899. DOI: 10.1080/10543406.2020.1757692.",
 "Brunner E, Vandemeulebroecke M, Mütze T. Win odds: an adaptation of the win ratio to include ties. Stat Med, 2021, 40(14): 3367-3384. DOI: 10.1002/sim.8967.",
 "Li F, Morgan KL, Zaslavsky AM. Balancing covariates via propensity score weighting. J Am Stat Assoc, 2018, 113(521): 390-400. DOI: 10.1080/01621459.2016.1260466.",
 "Robins JM, Rotnitzky A, Zhao LP. Estimation of regression coefficients when some regressors are not always observed. J Am Stat Assoc, 1994, 89(427): 846-866. DOI: 10.1080/01621459.1994.10476818.",
 "VanderWeele TJ, Ding P. Sensitivity analysis in observational research: introducing the E-value. Ann Intern Med, 2017, 167(4): 268-274. DOI: 10.7326/M16-2607.",
 "Kent DM, Paulus JK, van Klaveren D, et al. The Predictive Approaches to Treatment effect Heterogeneity (PATH) statement. Ann Intern Med, 2020, 172(1): 35-45. DOI: 10.7326/M18-3667.",
 "Razavi MK, Jaff MR, Miller LE. Safety and effectiveness of stent placement for iliofemoral venous outflow obstruction: systematic review and meta-analysis. Circ Cardiovasc Interv, 2015, 8(10): e002772. DOI: 10.1161/CIRCINTERVENTIONS.115.002772.",
 "Bashir R, Zack CJ, Zhao H, et al. Comparative outcomes of catheter-directed thrombolysis plus anticoagulation vs anticoagulation alone to treat lower-extremity proximal deep vein thrombosis. JAMA Intern Med, 2014, 174(9): 1494-1501. DOI: 10.1001/jamainternmed.2014.3415.",
]
B.append(dict(type="refs_here"))
NEW = {
 "@dag": "Greenland S, Pearl J, Robins JM. Causal diagrams for epidemiologic research. Epidemiology, 1999, 10(1): 37-48. DOI: 10.1097/00001648-199901000-00008.",
 "@sl": "van der Laan MJ, Polley EC, Hubbard AE. Super learner. Stat Appl Genet Mol Biol, 2007, 6(1): Article 25. DOI: 10.2202/1544-6115.1309.",
 "@dml": "Chernozhukov V, Chetverikov D, Demirer M, et al. Double/debiased machine learning for treatment and structural parameters. Econom J, 2018, 21(1): C1-C68. DOI: 10.1111/ectj.12097.",
 "@wa": "Wager S, Athey S. Estimation and inference of heterogeneous treatment effects using random forests. J Am Stat Assoc, 2018, 113(523): 1228-1242. DOI: 10.1080/01621459.2017.1319839.",
 "@grf": "Athey S, Tibshirani J, Wager S. Generalized random forests. Ann Stat, 2019, 47(2): 1148-1178. DOI: 10.1214/18-AOS1709.",
 "@rate": "Yadlowsky S, Fleming S, Shah N, et al. Evaluating treatment prioritization rules via rank-weighted average treatment effects. J Am Stat Assoc, 2025, 120(549): 38-51. DOI: 10.1080/01621459.2024.2393466.",
}

# =========================================================== SUPPLEMENT
pb()
h1("附录")
img("fig/figS0_dag.png", 0.0, 620)
cap("**附图 S1** 有向无环图（DAG）。左侧框内为已测量并调整的基线混杂因素；治疗后中介变量不予调整；虚线示未测量混杂及其对阴性对照结局的影响，点线示由 IPCW 处理的选择/删失路径")
img("fig/figS1.png", 0.0, 420)
cap("**附图 S2** 加权前后协变量标准化均数差（Love plot），虚线为 0.1")
img("fig/figS2.png", 0.0, 600)
cap("**附图 S3** 7 天内接受血栓清除的预测概率分布（A）与稳定化权重分布（B）")
img("fig/figS3.png", 0.0, 600)
cap("**附图 S4** 各随访时点加权 Villalta 总分（A）与 VEINES-QOL 评分（B），误差线为 95% CI")
img("fig/figS5_cf.png", 0.0, 620)
cap("**附图 S5** 探索性因果森林。A：样本外个体化效应（CATE）分布，实线为均值；B：按预测 CATE 三分位分组的双稳健效应估计；C：目标操作特征（TOC）曲线")
LN = {"mean": "均值模型", "logistic": "logistic 回归", "logistic_l1": "L1 惩罚 logistic", "gam_spline": "样条 logistic（类 GAM）", "random_forest": "随机森林", "gbm": "梯度提升树"}
cap("**附表 S1** SuperLearner 候选算法权重及交叉验证对数损失（以 24 个月中重度 PTS 分析为例）")
rows = [[LN[k], f"{SL['ms']['W']['e'][k]:.2f}", f"{SL['ms']['risk']['e'][k]:.3f}", f"{SL['ms']['W']['mu'][k]:.2f}", f"{SL['ms']['risk']['mu'][k]:.3f}", f"{SL['ms']['W']['r'][k]:.2f}"] for k in LN]
tab(["候选算法", "倾向评分权重", "倾向评分 CV 损失", "结局模型权重", "结局模型 CV 损失", "缺失模型权重"], rows, widths=[0.25, 0.15, 0.15, 0.15, 0.15, 0.15])
note(f"权重为 5 折交叉拟合中各训练集 SuperLearner 权重的均值（第 1 次随机划分）。结局可判定例数：中重度 PTS {SL['ms']['nobs']} 例，任意 PTS {SL['any']['nobs']} 例，大出血 {SL['mb']['nobs']} 例（地标人群 {SL['n_landmark']} 例）。")
cap("**附表 S2** 因果森林异质性评价（24 个月中重度 PTS）")
LB = {"age": "年龄（每岁）", "symdur": "症状持续时间（每天）", "iliac": "髂静脉受累", "mts": "髂静脉压迫综合征", "extent": "血栓累及范围评分（每分）", "pain": "基线疼痛评分（每分）", "bleedscore": "出血风险评分（每分）", "female": "女性"}
rows = [["平均效应（因果森林）", f"{sg(SL['cf_ate'][0])}（{sg(SL['cf_ate'][1])} 至 {sg(SL['cf_ate'][2])}）", "—"],
        ["校准检验：平均预测系数", f"{SL['calib']['mean_coef'][0]:.2f}（SE {SL['calib']['mean_coef'][1]:.2f}）", P(SL['calib']['mean_coef'][2])],
        ["校准检验：差异化预测系数", f"{SL['calib']['diff_coef'][0]:.2f}（SE {SL['calib']['diff_coef'][1]:.2f}）", P(SL['calib']['diff_coef'][2])],
        ["RATE：AUTOC，百分点", f"{sg(SL['rate']['autoc'][0])}（SE {SL['rate']['autoc'][1]*100:.1f}）", P(SL['rate']['autoc'][2])],
        ["RATE：Qini，百分点", f"{sg(SL['rate']['qini'][0])}（SE {SL['rate']['qini'][1]*100:.1f}）", P(SL['rate']['qini'][2])]]
for g, n_, pred, m_, lo, hi in SL["gates"]:
    rows.append([f"预测 CATE 三分位 {g+1}（n = {n_}，预测 {sg(pred)}）", f"{sg(m_)}（{sg(lo)} 至 {sg(hi)}）", "—"])
for k, b_, se_, p_ in SL["blp"]:
    rows.append([f"最佳线性投影：{LB[k]}", f"{sg(b_)}（SE {se_*100:.1f}）", P(p_)])
tab(["指标", "估计值（95% CI 或 SE）", "P"], rows, widths=[0.5, 0.35, 0.15])
note("单侧 P 值用于校准检验（检验系数 >0），其余为双侧。RD 与系数单位均为百分点；负值表示早期血栓清除降低中重度 PTS 风险，最佳线性投影中负系数表示该因素与更大获益相关。")

# ---------------- citation renumbering by first appearance
import re
def ids_of(inner):
    out = []
    for it in inner.split(","):
        it = it.strip()
        if it.startswith("@"): out.append(it); continue
        if "–" in it:
            a, b_ = it.split("–"); out += [f"o{k}" for k in range(int(a), int(b_) + 1)]
        else: out.append(f"o{int(it)}")
    return out
order = []
pat = re.compile(r"\^\[([^\]]+)\]\^")
for b in B:
    if b["type"] in ("p", "abs", "note", "caption"):
        for m_ in pat.finditer(b["text"]):
            for k in ids_of(m_.group(1)):
                if k not in order: order.append(k)
num = {k: i + 1 for i, k in enumerate(order)}
def fmt_nums(ns):
    ns = sorted(set(ns)); out = []; i = 0
    while i < len(ns):
        j = i
        while j + 1 < len(ns) and ns[j + 1] == ns[j] + 1: j += 1
        out.append(f"{ns[i]}–{ns[j]}" if j - i >= 2 else ",".join(str(x) for x in ns[i:j + 1])); i = j + 1
    return ",".join(out)
for b in B:
    if b["type"] in ("p", "abs", "note", "caption"):
        b["text"] = pat.sub(lambda m_: "^[" + fmt_nums([num[k] for k in ids_of(m_.group(1))]) + "]^", b["text"])
allref = {f"o{i+1}": r for i, r in enumerate(refs)}; allref.update(NEW)
missing = [k for k in allref if k not in num]
assert not missing, f"uncited refs: {missing}"
idx = next(i for i, b in enumerate(B) if b["type"] == "refs_here")
B[idx:idx + 1] = [dict(type="ref", text=f"[{num[k]}] {allref[k]}") for k in order]
print("refs total", len(order))

# fix image ratios from files
from PIL import Image
for b in B:
    if b["type"] == "img":
        w, h = Image.open(b["path"]).size; b["ratio"] = h / w
json.dump(B, open("blocks.json", "w"), ensure_ascii=False)
print("blocks", len(B), "refs", len(refs))
