"""Core functions: data prep, CCW weights, weighted Aalen-Johansen, weighted win ratio."""
import numpy as np, pandas as pd, warnings
from sklearn.linear_model import LogisticRegression
warnings.filterwarnings("ignore")

DATA = "/home/claude/work/data.xlsx"
GRACE = 7
HORIZON = 730

COV_CONT = ["age", "bmi", "extent", "symdur", "pain", "legdiff", "charlson", "hb", "plt",
            "egfr", "ldd", "lcrp", "lnlr", "bleedscore", "year"]
COV_BIN = ["female", "left", "iliac", "cfv", "mts", "provoked", "dm", "htn", "cad", "stroke",
           "antiplt"]
COV_CTR = ["c2", "c3", "c4"]


def load():
    x = pd.ExcelFile(DATA)
    df = pd.read_excel(x, 0)
    v = pd.read_excel(x, 1)
    r = pd.DataFrame({
        "id": df["患者编号"], "center": df["研究中心"], "year": df["入组年份"],
        "age": df["年龄（岁）"], "female": df["女性（1是0否）"], "bmi": df["体质指数（kg/m²）"],
        "left": df["左侧DVT（1是0否）"], "iliac": df["髂静脉受累（1是0否）"],
        "cfv": df["股总静脉受累（1是0否）"], "mts": df["髂静脉压迫综合征（1是0否）"],
        "extent": df["血栓累及范围评分"], "symdur": df["症状持续时间（天）"],
        "pain": df["基线疼痛评分（0–10）"], "legdiff": df["双下肢腿围差（厘米）"],
        "provoked": df["诱发性DVT（1是0否）"], "dm": df["糖尿病（1是0否）"],
        "htn": df["高血压（1是0否）"], "cad": df["冠心病（1是0否）"],
        "stroke": df["既往脑卒中（1是0否）"], "charlson": df["查尔森合并症指数"],
        "hb": df["血红蛋白（g/L）"], "plt": df["血小板（×10⁹/L）"],
        "egfr": df["估算肾小球滤过率"], "dd": df["D-二聚体（mg/L）"],
        "crp": df["C反应蛋白（mg/L）"], "nlr": df["中性粒细胞与淋巴细胞比值"],
        "bleedscore": df["出血风险评分"], "antiplt": df["使用抗血小板药（1是0否）"],
        "trt": df["7天内血栓清除（1是0否）"], "tday": df["血栓清除距确诊天数"],
        "method": df["血栓清除方式（原编码）"], "stent": df["髂静脉支架置入（1是0否）"],
        "fu0": df["总随访时间（天）"],
        "death": df["全因死亡（1是0否）"], "death_t": df["死亡发生日（距确诊）"],
        "vte": df["复发静脉血栓栓塞（1是0否）"], "vte_t": df["复发静脉血栓栓塞发生日"],
        "mb": df["大出血（1是0否）"], "mb_t": df["大出血发生日"],
        "crnmb": df["临床相关非大出血（1是0否）"], "crnmb_t": df["临床相关非大出血发生日"],
        "reint": df["再次介入（1是0否）"], "reint_t": df["再次介入发生日"],
        "nc": df["阴性对照结局（1是0否）"], "nc_t": df["阴性对照结局发生日"],
        "any_t": df["首次检出PTS时间（天）"], "ms_t": df["首次检出中重度PTS时间（天）"],
        "v24": df["24个月Villalta总分"],
    })
    r["ldd"] = np.log(r.dd); r["lcrp"] = np.log(r.crp); r["lnlr"] = np.log(r.nlr)
    for c in [2, 3, 4]:
        r[f"c{c}"] = (r.center == c).astype(int)
    last = v.groupby("患者编号")["距确诊天数"].max()
    r["ptsfu"] = r.id.map(last).fillna(0.0)
    # visits are recorded at nominal days; follow-up extended to the nominal day of the last visit
    r["fu"] = np.maximum(r.fu0, r.ptsfu)
    r.loc[r.death == 1, "fu"] = r.loc[r.death == 1, "death_t"]
    r["ltfu"] = ((r.fu < HORIZON) & (r.death == 0)).astype(int)
    return r, v


def covmat(d, cols=None):
    cols = cols or (COV_CONT + COV_BIN + COV_CTR)
    X = d[cols].astype(float).values
    return X


def _std(X, ref=None):
    ref = X if ref is None else ref
    mu = ref.mean(0); sd = ref.std(0); sd[sd == 0] = 1
    return (X - mu) / sd


def fit_logit(X, y, C=1e6):
    m = LogisticRegression(C=C, max_iter=5000)
    m.fit(X, y)
    return m


# ---------------------------------------------------------------- CCW weights
def trt_weights(d, grace=GRACE, cols=None):
    """Pooled logistic for daily hazard of intervention during grace period.
    Returns arrays: haz (n x (grace+1)) daily hazard for each patient."""
    X = _std(covmat(d, cols))
    n = len(d)
    rows, ys, days = [], [], []
    tday = d.tday.values
    for i in range(n):
        last = tday[i] if tday[i] >= 0 else grace
        last = min(last, grace)
        for k in range(0, last + 1):
            rows.append(i); days.append(k)
            ys.append(1 if (tday[i] == k) else 0)
    rows = np.array(rows); days = np.array(days); ys = np.array(ys)
    D = np.zeros((len(days), grace + 1)); D[np.arange(len(days)), days] = 1
    Z = np.hstack([X[rows], D[:, 1:]])
    m = fit_logit(Z, ys)
    # predict all patients all days
    haz = np.zeros((n, grace + 1))
    for k in range(grace + 1):
        Dk = np.zeros((n, grace + 1)); Dk[:, k] = 1
        haz[:, k] = m.predict_proba(np.hstack([X, Dk[:, 1:]]))[:, 1]
    return haz


def discrete_cens_G(d, idx, cens_time, cens_ind, grid, cols=None):
    """Pooled logistic censoring model on intervals defined by grid (list of upper bounds).
    idx: boolean mask of patients included (an arm). Returns G at each grid point (n_sel x len(grid)),
    G[:,k] = P(uncensored through interval k)."""
    dd = d[idx]
    X = _std(covmat(dd, cols))
    n = len(dd)
    ct = cens_time[idx]; ci = cens_ind[idx]
    lows = [GRACE] + list(grid[:-1])
    rows, ks, ys = [], [], []
    for i in range(n):
        for k, (lo, hi) in enumerate(zip(lows, grid)):
            if ct[i] <= lo:
                break
            rows.append(i); ks.append(k)
            ys.append(1 if (ci[i] == 1 and ct[i] <= hi and ct[i] < grid[-1]) else 0)
    rows = np.array(rows); ks = np.array(ks); ys = np.array(ys)
    K = len(grid)
    kk = ks / (K - 1)
    T = np.column_stack([kk, kk ** 2])
    if ys.sum() < 3:
        return np.ones((n, K))
    m = fit_logit(np.hstack([X[rows], T]), ys, C=1.0)
    G = np.ones((n, K))
    surv = np.ones(n)
    for k in range(K):
        Tk = np.column_stack([np.full(n, k / (K - 1)), np.full(n, (k / (K - 1)) ** 2)])
        h = m.predict_proba(np.hstack([X, Tk]))[:, 1]
        surv = surv * (1 - h)
        G[:, k] = surv
    return G


CLIN_GRID = np.arange(37, HORIZON + 1, 30.0)  # ~monthly intervals after grace
CLIN_GRID = np.append(CLIN_GRID[CLIN_GRID < HORIZON], HORIZON)
PTS_GRID = np.array([183.0, 365.0, 548.0, 730.0])


def build_clones(d, grace=GRACE, trunc=99, cols=None, pp=False, ltfu_ipcw=True):
    """Return dict for arm A and B with per-clone arrays needed by AJ and WR.
    Weight functions are represented as: w_grace (weight applying to t<=grace, per day array),
    w_post (scalar per clone for t>grace from treatment-censoring), and G functions for LTFU."""
    n = len(d)
    W = GRACE  # intervention window observed in the data (days 0-7)
    haz = trt_weights(d, W, cols)
    tday = d.tday.values.astype(float)
    anytrt = tday >= 0
    treated = anytrt & (tday <= grace)
    surv_untr = np.cumprod(1 - haz, axis=1)  # P(untreated through day k)
    pA = 1 - surv_untr[:, grace]
    qB = surv_untr[:, W]
    wA_post = np.where(treated, 1 / pA, 0.0)
    wB_post = np.where(~anytrt, 1 / qB, 0.0)
    if trunc is not None:
        capA = np.percentile(wA_post[treated], trunc)
        capB = np.percentile(wB_post[~anytrt], trunc)
        wA_post = np.minimum(wA_post, capA); wB_post = np.minimum(wB_post, capB)
    cumB = np.hstack([np.ones((n, 1)), surv_untr[:, :W]])  # index t -> prod_{d<t}(1-h_d)

    fu = d.fu.values.astype(float); pf = d.ptsfu.values.astype(float)
    out = {}
    for arm in "AB":
        if arm == "A":
            fu_c = np.where(treated, fu, np.minimum(fu, grace + 0.5))
            pf_c = np.where(treated, pf, 0.0)
            post = wA_post
            gw = np.ones((n, grace + 1))
            unc = treated
        else:
            fu_c = np.where(anytrt, np.minimum(fu, tday - 0.5), fu)
            pf_c = np.where(anytrt, 0.0, pf)
            post = wB_post
            gw = 1 / cumB
            unc = ~anytrt
        ev = {}
        for k in ["death", "vte", "mb", "crnmb", "reint", "nc"]:
            t = d[k + "_t"].values.astype(float)
            t = np.where(d[k].values == 1, t, np.inf)
            t = np.where(t <= fu_c, t, np.inf)
            ev[k] = t
        for k in ["any", "ms"]:
            t = d[k + "_t"].values.astype(float)
            t = np.where(np.isnan(t), np.inf, t)
            t = np.where(t <= pf_c, t, np.inf)
            ev[k] = t
        out[arm] = dict(fu=fu_c, pf=pf_c, post=post, gw=gw, ev=ev, uncens=unc)
    # per-protocol: in B arm, censor at rescue re-intervention (time-varying IPCW via discrete model)
    if pp:
        B = out["B"]
        rt = np.where((d.reint.values == 1) & (~anytrt), d.reint_t.values, np.inf)
        ct = np.minimum(B["fu"], rt)
        ci = (rt <= B["fu"]).astype(int)
        idx = ~anytrt
        G = discrete_cens_G(d, idx, ct, ci, CLIN_GRID, cols)
        Gfull = np.ones((n, len(CLIN_GRID))); Gfull[idx] = G
        B["fu"] = np.where(idx, np.minimum(B["fu"], rt - 0.5), B["fu"])
        for k in B["ev"]:
            B["ev"][k] = np.where(B["ev"][k] <= B["fu"], B["ev"][k], np.inf)
        B["pf"] = np.where(idx & (rt < np.inf), np.minimum(B["pf"], rt - 0.5), B["pf"])
        for k in ["any", "ms"]:
            B["ev"][k] = np.where(B["ev"][k] <= B["pf"], B["ev"][k], np.inf)
        B["G_pp"] = Gfull
    # LTFU IPCW (clinical and PTS) within uncensored clones of each arm
    for arm in "AB":
        o = out[arm]; idx = o["uncens"]
        if ltfu_ipcw:
            ct = d.fu.values.astype(float); ci = d.ltfu.values
            Gc = np.ones((n, len(CLIN_GRID)))
            Gc[idx] = discrete_cens_G(d, idx, ct, ci, CLIN_GRID, cols)
            # PTS censoring: last visit < 730 while alive at the next scheduled visit
            nextvisit = np.array([next((g for g in PTS_GRID if g > p), np.inf) for p in pf])
            pci = ((pf < HORIZON) & ~((d.death.values == 1) & (d.death_t.values < nextvisit))).astype(int)
            pct = np.where(pci == 1, nextvisit, np.where(d.death.values == 1, d.death_t.values, HORIZON))
            Gp = np.ones((n, len(PTS_GRID)))
            Gp[idx] = discrete_cens_G(d, idx, pct, pci, PTS_GRID, cols)
        else:
            Gc = np.ones((n, len(CLIN_GRID))); Gp = np.ones((n, len(PTS_GRID)))
        o["Gc"] = Gc; o["Gp"] = Gp
        if arm == "B" and pp:
            o["Gc"] = o["Gc"] * o["G_pp"]
            # PTS weights use clinical PP G at visit days
            gi = np.searchsorted(CLIN_GRID, PTS_GRID - 1e-9)
            o["Gp"] = o["Gp"] * o["G_pp"][:, gi]
    if ltfu_ipcw and trunc is not None:
        for arm in "AB":
            o = out[arm]
            for key in ["Gc", "Gp"]:
                inv = 1 / o[key]
                cap = np.percentile(inv[o["uncens"]], trunc)
                o[key] = 1 / np.minimum(inv, cap)
    out["haz"] = haz; out["pA"] = pA; out["treated"] = treated
    return out


def weight_at(o, t, kind="clin", idx=None):
    """Weight of clones idx (default all) at times t (array same length as idx)."""
    n = len(o["fu"])
    idx = np.arange(n) if idx is None else np.asarray(idx)
    t = np.broadcast_to(np.asarray(t, dtype=float), idx.shape)
    grace = o["gw"].shape[1] - 1
    w = np.empty(idx.size)
    ing = t <= grace + 0.5
    ti = np.clip(np.ceil(t).astype(int), 0, grace)
    w[ing] = o["gw"][idx[ing], ti[ing]]
    post = ~ing
    tp = t[post]; ip = idx[post]
    if kind == "clin":
        k = np.searchsorted(CLIN_GRID, tp - 1e-9) - 1
        G = np.where(k >= 0, o["Gc"][ip, np.clip(k, 0, None)], 1.0)
    else:
        kv = np.clip(np.searchsorted(PTS_GRID, tp - 1e-9), 0, len(PTS_GRID) - 1)
        G = o["Gp"][ip, kv]
    w[post] = o["post"][ip] / G
    return w


# --------------------------------------------------------- weighted Aalen-Johansen
def wAJ(o, ev_key, times=(365, 730)):
    """Cumulative incidence (death competing) with time-varying clone weights.
    Returns dict time->CIF and step list."""
    kind = "pts" if ev_key in ("any", "ms") else "clin"
    te = o["ev"][ev_key]
    td = o["ev"]["death"] if ev_key != "death" else np.full(len(te), np.inf)
    end = o["pf"] if kind == "pts" else o["fu"]
    T = np.where(np.isfinite(te), te, np.where(np.isfinite(td), td, end))
    if kind == "clin":
        T = np.minimum(T, o["fu"])
    cause = np.where(np.isfinite(te) & (te <= T), 1, np.where(np.isfinite(td) & (td <= T), 2, 0))
    keep = np.where(T > 0)[0]
    T = T[keep]; cause = cause[keep]
    ut = np.unique(T[cause > 0])
    S = 1.0; F = 0.0; steps = [(0.0, 0.0)]
    for t in ut:
        atrisk = T >= t
        w = weight_at(o, np.full(keep.size, t), kind, keep)
        Y = (w * atrisk).sum()
        if Y <= 0:
            continue
        d1 = (w * ((T == t) & (cause == 1))).sum()
        d2 = (w * ((T == t) & (cause == 2))).sum()
        F += S * d1 / Y
        S *= (1 - (d1 + d2) / Y)
        steps.append((t, F))
    st = np.array(steps)
    res = {tt: st[st[:, 0] <= tt, 1][-1] for tt in times}
    return res, st


# ------------------------------------------------------------- weighted win ratio
DEFAULT_TIERS = [("death", "clin"), ("vte", "clin"), ("mb", "clin"), ("ms", "pts"), ("any", "pts")]


def win_ratio(A, B, tiers=DEFAULT_TIERS, weighted=True, horizon=HORIZON):
    nA = len(A["fu"]); nB = len(B["fu"])
    # restrict to clones with any follow-up
    ia = np.arange(nA); ib = np.arange(nB)
    I, J = np.meshgrid(ia, ib, indexing="ij"); I = I.ravel(); J = J.ravel()
    undecided = np.ones(I.size, bool)
    win_w = np.zeros(I.size); loss_w = np.zeros(I.size)
    tier_res = []
    for key, kind in tiers:
        if kind == "clin":
            H = np.minimum(A["fu"][I], B["fu"][J])
        else:
            H = np.minimum(np.minimum(A["pf"][I], B["pf"][J]), np.minimum(A["fu"][I], B["fu"][J]))
        ta = A["ev"][key][I]; tb = B["ev"][key][J]
        ta = np.where(ta <= H, ta, np.inf); tb = np.where(tb <= H, tb, np.inf)
        a_loses = undecided & (ta < tb)
        a_wins = undecided & (tb < ta)
        tau = np.where(a_loses, ta, tb)
        wpair = np.zeros(I.size)
        dec = a_loses | a_wins
        if weighted:
            di = np.where(dec)[0]
            wpair[di] = weight_at(A, tau[di], kind, I[di]) * weight_at(B, tau[di], kind, J[di])
        else:
            wpair[dec] = 1.0
        W = (wpair * a_wins).sum(); L = (wpair * a_loses).sum()
        tier_res.append((key, W, L))
        win_w += wpair * a_wins; loss_w += wpair * a_loses
        undecided &= ~(a_loses | a_wins)
    # ties: pairs completing full follow-up for all tiers
    Hc = np.minimum(A["fu"][I], B["fu"][J])
    Hp = np.minimum(A["pf"][I], B["pf"][J])
    full = undecided & (Hc >= horizon - 1e-9) & (Hp >= horizon - 1e-9)
    if weighted:
        fi = np.where(full)[0]
        tie_w = (weight_at(A, np.full(fi.size, float(horizon)), "pts", I[fi]) *
                 weight_at(B, np.full(fi.size, float(horizon)), "pts", J[fi])).sum()
    else:
        tie_w = full.sum()
    Wt = win_w.sum(); Lt = loss_w.sum()
    tot = Wt + Lt + tie_w
    return dict(WR=Wt / Lt, WO=(Wt + 0.5 * tie_w) / (Lt + 0.5 * tie_w),
                NB=(Wt - Lt) / tot, pW=Wt / tot, pL=Lt / tot, pT=tie_w / tot,
                tiers=[(k, w / tot, l / tot) for k, w, l in tier_res])
