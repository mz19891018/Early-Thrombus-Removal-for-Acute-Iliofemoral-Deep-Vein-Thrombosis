import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
fm.fontManager.addfont("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
plt.rcParams.update({"font.family": "Noto Sans CJK JP", "savefig.dpi": 300})
fig, ax = plt.subplots(figsize=(10.5, 6.6)); ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")
INK = "#222"; G = "#8a8a82"
def box(x, y, w, h, t, fc="#f4f3ee", ec="#c3c2b7", ls="-", lw=0.8, fs=8.2, bold=False):
    ax.add_patch(FancyBboxPatch((x - w/2, y - h/2), w, h, boxstyle="round,pad=0.4,rounding_size=1.5", fc=fc, ec=ec, ls=ls, lw=lw))
    ax.text(x, y, t, ha="center", va="center", fontsize=fs, color=INK, linespacing=1.35, fontweight="bold" if bold else "normal")
def arr(p, q, c="#555", ls="-", lw=1.0, rad=0.0):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=9, color=c, ls=ls, lw=lw, connectionstyle=f"arc3,rad={rad}", shrinkA=0, shrinkB=0))
# confounder cluster
ax.add_patch(FancyBboxPatch((1, 3), 29.5, 96, boxstyle="round,pad=0.3,rounding_size=2", fc="white", ec=G, ls="--", lw=0.8))
ax.text(15.5, 94, "已测量基线混杂因素 L\n（零时点或之前，均已调整）", ha="center", va="center", fontsize=8.2, color=INK, fontweight="bold")
items = ["人口学：年龄、性别、BMI", "血栓特征：范围评分、髂静脉/股总\n静脉受累、髂静脉压迫、左侧、症状天数", "症状严重度：疼痛评分、腿围差",
         "出血风险：出血评分、Hb、PLT、\neGFR、抗血小板药", "合并症与诱因：DM、HTN、CAD、\n卒中、Charlson、诱发性", "炎症指标：D-二聚体、CRP、NLR", "系统层面：研究中心、入组年份"]
ys = [84, 73, 62, 50, 38, 27, 16]
for y, t in zip(ys, items): box(15.5, y, 26, 8 if "\n" in t else 5, t, fs=7.4)
# nodes
box(52, 50, 18, 12, "暴露 A\n7 天内血栓清除\n（CDT/PMT ± 支架）", fc="#e7f0fb", ec="#2a78d6", lw=1.4, bold=True)
box(88, 50, 20, 12, "结局 Y（24 个月）\n死亡、复发 VTE、大出血\n中重度/任意 PTS", fc="#fdece4", ec="#eb6834", lw=1.4, bold=True)
box(68, 70, 21, 11, "治疗后中介变量（不调整）\n支架置入、溶解程度/通畅\n介入后抗栓方案", fc="white")
box(50, 89, 27, 11, "未测量混杂 U\n医生耐受判断、患者意愿/支付能力\n民族、医保、滤器、初始抗凝药", fc="white", ec=G, ls="--")
box(90, 92, 16, 8, "阴性对照结局\n感染性住院", fc="white", ec=G, ls="--")
box(88, 14, 21, 9, "失访 / PTS 评估缺失 C\n（IPCW 校正）", fc="white")
# edges
arr((30.5, 50), (42.6, 50))                                  # L -> A
arr((30.5, 40), (80, 43.6), rad=0.18)                        # L -> Y
arr((30.5, 20), (77.1, 14), ls=":", c=G)                     # L -> C
arr((30.5, 97), (81.6, 95), ls="--", c=G, rad=-0.06)           # L -> NC
arr((61.4, 50), (77.6, 50), c="#2a78d6", lw=2)               # A -> Y
arr((56, 56.4), (62, 64.1))                                    # A -> M
arr((78.9, 68), (84, 56.4))                                  # M -> Y
arr((56, 43.6), (81, 18.9), ls=":", c=G)                       # A -> C
arr((50, 83.1), (50, 56.4), ls="--", c=G)                    # U -> A
arr((64, 88), (93, 56.4), ls="--", c=G, rad=-0.35)         # U -> Y
arr((64, 91), (81.6, 92), ls="--", c=G)                  # U -> NC
arr((88, 18.9), (88, 43.6), ls=":", c=G)                       # C affects observed Y
from matplotlib.lines import Line2D
h = [Line2D([], [], color="#2a78d6", lw=2, label="待估计的因果效应"), Line2D([], [], color="#555", lw=1, label="已调整的混杂/中介路径"),
     Line2D([], [], color=G, lw=1, ls="--", label="未测量混杂及阴性对照路径"), Line2D([], [], color=G, lw=1, ls=":", label="选择/删失路径（IPCW）")]
ax.legend(handles=h, loc="lower center", bbox_to_anchor=(0.66, -0.04), ncol=2, frameon=False, fontsize=7.2)
fig.savefig("fig/figS0_dag.png", bbox_inches="tight")
