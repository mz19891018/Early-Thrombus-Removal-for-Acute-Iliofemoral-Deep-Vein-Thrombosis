import numpy as np, pandas as pd, pickle, json
from core import *
from core import _std
d, v = load()
R = {}
a = d.trt.values == 1
cl = build_clones(d)
wA = cl["A"]["post"]; wB = cl["B"]["post"]
w = np.where(a, wA, wB)  # post-grace CCW treatment weight for uncensored clone

VARS = [
    ("age", "年龄，岁", "mean"), ("female", "女性", "bin"), ("bmi", "BMI，kg/m²", "mean"),
    ("left", "左侧 DVT", "bin"), ("iliac", "髂静脉受累", "bin"), ("cfv", "股总静脉受累", "bin"),
    ("mts", "髂静脉压迫综合征", "bin"), ("extent", "血栓累及范围评分", "mean"),
    ("symdur", "症状持续时间，天", "median"), ("pain", "基线疼痛评分（0–10）", "mean"),
    ("legdiff", "双下肢腿围差，cm", "mean"), ("provoked", "诱发性 DVT", "bin"),
    ("dm", "糖尿病", "bin"), ("htn", "高血压", "bin"), ("cad", "冠心病", "bin"),
    ("stroke", "既往脑卒中", "bin"), ("charlson", "Charlson 合并症指数", "median"),
    ("hb", "血红蛋白，g/L", "mean"), ("plt", "血小板，×10⁹/L", "mean"), ("egfr", "eGFR，mL/min/1.73m²", "mean"),
    ("dd", "D-二聚体，mg/L", "median"), ("crp", "C 反应蛋白，mg/L", "median"), ("nlr", "NLR", "median"),
    ("bleedscore", "出血风险评分", "median"), ("antiplt", "使用抗血小板药", "bin"),
    ("c2", "中心 2", "bin"), ("c3", "中心 3", "bin"), ("c4", "中心 4", "bin"), ("year", "入组年份", "median"),
]


def wmean(x, w):
    return np.sum(w * x) / np.sum(w)


def wvar(x, w):
    m = wmean(x, w); return np.sum(w * (x - m) ** 2) / np.sum(w)


def smd(x, a, w=None):
    w = np.ones(len(x)) if w is None else w
    x1, w1 = x[a], w[a]; x0, w0 = x[~a], w[~a]
    m1, m0 = wmean(x1, w1), wmean(x0, w0)
    # pooled SD from unweighted samples (standard practice)
    s = np.sqrt((x[a].var(ddof=1) + x[~a].var(ddof=1)) / 2)
    return (m1 - m0) / s if s > 0 else 0.0


rows = []
d1 = d[a]; d0_ = d[~a]
c1 = d[d.center == 1]
for k, lab, typ in VARS:
    x = d[k].values.astype(float)
    if typ == "bin":
        f = lambda s: f"{int(s.sum())} ({s.mean()*100:.1f})"
    elif typ == "mean":
        f = lambda s: f"{s.mean():.1f} ± {s.std(ddof=1):.1f}"
    else:
        f = lambda s: f"{s.median():g} ({s.quantile(.25):g}–{s.quantile(.75):g})"
    rows.append(dict(var=k, label=lab, all=f(d[k]), A=f(d1[k]), B=f(d0_[k]),
                     smd_crude=smd(x, a), smd_w=smd(x, a, w)))
# add center 1 row for completeness
tab = pd.DataFrame(rows)
R["table2"] = tab
print(tab.to_string())
print("max |SMD| crude", tab.smd_crude.abs().max(), "weighted", tab.smd_w.abs().max())

# weights summary
sw = np.where(a, wA * a.mean(), wB * (1 - a.mean()))
ess = lambda ww: ww.sum() ** 2 / (ww ** 2).sum()
R["weights"] = dict(
    unstab_A=(wA[a].mean(), wA[a].min(), wA[a].max()), unstab_B=(wB[~a].mean(), wB[~a].min(), wB[~a].max()),
    stab_A=(sw[a].mean(), sw[a].min(), sw[a].max()), stab_B=(sw[~a].mean(), sw[~a].min(), sw[~a].max()),
    ess_A=ess(wA[a]), ess_B=ess(wB[~a]),
    pA=(cl["pA"].min(), np.percentile(cl["pA"], 5), np.median(cl["pA"]), np.percentile(cl["pA"], 95), cl["pA"].max()),
    pA_lt05=(cl["pA"] < 0.05).sum(), pA_gt95=(cl["pA"] > 0.95).sum())
# LTFU weight summary
for arm in "AB":
    o = cl[arm]; inv = 1 / o["Gc"][o["uncens"], -1]; invp = 1 / o["Gp"][o["uncens"], -1]
    R["weights"][f"ltfu_{arm}"] = (inv.mean(), inv.max(), invp.mean(), invp.max())
print(R["weights"])

# treatment details
t = d[a]
R["trt"] = dict(
    n=len(t), day_median=t.tday.median(), day_q=(t.tday.quantile(.25), t.tday.quantile(.75)), day_p90=t.tday.quantile(.9),
    day_counts=t.tday.value_counts().sort_index().to_dict(),
    within72=(t.tday <= 3).mean(), method=t.method.value_counts().sort_index().to_dict(), stent=int(t.stent.sum()),
    stent_by_method=t.groupby("method").stent.agg(["sum", "count"]).to_dict(),
    center_rate=d.groupby("center").trt.agg(["sum", "count", "mean"]).to_dict(),
    year_rate=d.groupby("year").trt.agg(["sum", "count", "mean"]).to_dict(),
    reint_B=int(d.loc[~a, "reint"].sum()), reint_A=int(d.loc[a, "reint"].sum()),
)
print(R["trt"])

# follow-up & completeness
R["fu"] = dict(
    median_fu=d.fu.median(), ltfu=int(d.ltfu.sum()), ltfu_A=int(d.ltfu[a].sum()), ltfu_B=int(d.ltfu[~a].sum()),
    deaths=int(d.death.sum()), v24=int(d.v24.notna().sum()), v24_A=int(d.v24[a].notna().sum()), v24_B=int(d.v24[~a].notna().sum()),
    visits=v.groupby("随访月份").size().to_dict(),
    noVisit=int((d.ptsfu == 0).sum()),
    grace_events=dict(vte=d.loc[(d.vte == 1) & (d.vte_t <= 7), ["id", "vte_t", "tday"]].values.tolist(),
                      crnmb=d.loc[(d.crnmb == 1) & (d.crnmb_t <= 7), ["id", "crnmb_t", "tday"]].values.tolist()),
    mb_10d=int(((d.mb == 1) & (d.mb_t <= 10)).sum()), mb_30d=int(((d.mb == 1) & (d.mb_t <= 30)).sum()),
    mb_first=d.mb_t.min(),
)
# crude counts
cr = {}
for k in ["death", "vte", "mb", "crnmb", "reint", "nc"]:
    cr[k] = (int(d.loc[a, k].sum()), int(d.loc[~a, k].sum()))
cr["any"] = (int(d.loc[a, "any_t"].notna().sum()), int(d.loc[~a, "any_t"].notna().sum()))
cr["ms"] = (int(d.loc[a, "ms_t"].notna().sum()), int(d.loc[~a, "ms_t"].notna().sum()))
R["crude"] = cr
print(R["fu"], cr)

# 24-month cross-sectional and longitudinal outcomes (landmark IPTW weights = CCW post-grace weights)
vv = v.merge(d[["id", "trt"]], left_on="患者编号", right_on="id")
wmap = dict(zip(d.id, w))
vv["w"] = vv.id.map(wmap)
traj = {}
for m in [6, 12, 18, 24]:
    s = vv[vv["随访月份"] == m]
    for arm in (1, 0):
        q = s[s.trt == arm]
        traj[(m, arm)] = dict(n=len(q), villalta=wmean(q["Villalta总分"].values, q.w.values),
                              villalta_sd=np.sqrt(wvar(q["Villalta总分"].values, q.w.values)),
                              qol=wmean(q["静脉疾病生活质量评分"].values, q.w.values),
                              qol_sd=np.sqrt(wvar(q["静脉疾病生活质量评分"].values, q.w.values)),
                              patent=wmean(q["静脉通畅（1是0否）"].values, q.w.values),
                              anyp=wmean(q["任意PTS（1是0否）"].values, q.w.values),
                              msp=wmean(q["中重度PTS（1是0否）"].values, q.w.values),
                              ulcer=int(q["静脉性溃疡（1是0否）"].sum()))
R["traj"] = traj


# weighted difference with robust SE
def wdiff(y, arm, ww):
    out = []
    m1 = wmean(y[arm], ww[arm]); m0 = wmean(y[~arm], ww[~arm])
    se1 = np.sqrt(np.sum(ww[arm] ** 2 * (y[arm] - m1) ** 2)) / ww[arm].sum()
    se0 = np.sqrt(np.sum(ww[~arm] ** 2 * (y[~arm] - m0) ** 2)) / ww[~arm].sum()
    diff = m1 - m0; se = np.sqrt(se1 ** 2 + se0 ** 2)
    from scipy.stats import norm
    return dict(m1=m1, m0=m0, diff=diff, lo=diff - 1.96 * se, hi=diff + 1.96 * se, p=2 * (1 - norm.cdf(abs(diff / se))))


cs = {}
for m in [6, 12, 24]:
    s = vv[vv["随访月份"] == m]
    arm = s.trt.values == 1; ww = s.w.values
    for col, key in [("Villalta总分", "villalta"), ("静脉疾病生活质量评分", "qol"), ("静脉通畅（1是0否）", "patent"),
                     ("任意PTS（1是0否）", "anyp"), ("中重度PTS（1是0否）", "msp")]:
        cs[(m, key)] = wdiff(s[col].values.astype(float), arm, ww)
R["cross"] = cs
for k, val in cs.items():
    print(k, {kk: round(vv_, 3) for kk, vv_ in val.items()})

# Villalta item analysis at 24 months (symptoms vs signs)
items_sym = ["疼痛", "痉挛", "沉重感", "感觉异常", "瘙痒"]
items_sig = ["胫前水肿", "皮肤硬化", "色素沉着", "皮肤发红", "静脉扩张", "小腿压痛"]
s = vv[vv["随访月份"] == 24]
arm = s.trt.values == 1; ww = s.w.values
R["items24"] = dict(sym=wdiff(s[items_sym].sum(1).values.astype(float), arm, ww),
                    sig=wdiff(s[items_sig].sum(1).values.astype(float), arm, ww))
print(R["items24"])

# E-values
pickle.dump(R, open("res_desc.pkl", "wb"))
pickle.dump(dict(w=w, a=a, pA=cl["pA"], X=covmat(d)), open("res_w.pkl", "wb"))
