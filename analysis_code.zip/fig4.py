import numpy as np, pickle, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.ticker
from matplotlib import font_manager as fm
fm.fontManager.addfont("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
plt.rcParams.update({"font.family": "Noto Sans CJK JP", "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#c3c2b7", "savefig.dpi": 300, "axes.titlesize": 9, "axes.titleweight": "bold"})
CA, INK, GR = "#2a78d6", "#222", "#9a9a92"
M = pickle.load(open("res_main.pkl", "rb"))["main"]; S = pickle.load(open("res_sens.pkl", "rb"))
SUB = pickle.load(open("res_sub.pkl", "rb")); H = pickle.load(open("res_hte.pkl", "rb"))
rows = [("主分析", M, True), ("S1 宽限期 3 天", S["S1_grace3"], False), ("S1 宽限期 5 天", S["S1_grace5"], False),
        ("S2 符合方案类比", S["S2_pp"], False), ("S3 地标 + 重叠权重", S["S3_overlap"], False), ("S3 地标 + IPTW", S["S3_iptw"], False),
        ("S4 仅 PMT", S["S4_pmt"], False), ("S5 2019 年起", S["S5_2019on"], False), ("S9 截尾 P95", S["S9_t95"], False),
        ("S9 不截尾", S["S9_none"], False), ("S10 不校正失访", S["S10_noltfu"], False), (None, None, False)]
for k, lab in [("symdur_le7", "症状 ≤7 天"), ("symdur_gt7", "症状 8～14 天"), ("iliac_yes", "髂静脉受累"), ("iliac_no", "无髂静脉受累"),
               ("age_lt50", "年龄 <50 岁"), ("age_ge50", "年龄 ≥50 岁"), ("mts_yes", "髂静脉压迫：是"), ("mts_no", "髂静脉压迫：否")]:
    rows.append((lab, SUB[k]["summ"], False))
for g, lab in enumerate(["PTS 低风险层", "PTS 中风险层", "PTS 高风险层"]):
    rows.append((lab, H[f"risk{g}"]["summ"], False))
n = len(rows)
fig, axs = plt.subplots(1, 3, figsize=(7.4, 6.6), sharey=True, gridspec_kw=dict(wspace=0.12))
y = np.arange(n)[::-1]
for ax, key, title, log in [(axs[0], "ms_730_RD", "A  中重度 PTS RD（%）", False), (axs[1], "mb_730_RD", "B  大出血 RD（%）", False), (axs[2], "WR", "C  Win ratio", True)]:
    for yi, (lab, r, main) in zip(y, rows):
        if r is None: continue
        e, lo, hi = r[key][:3]
        if not log: e, lo, hi = e * 100, lo * 100, hi * 100
        lo_c = lo; hi_c = hi
        lim = (0.3, 4) if log else ((-40, 20) if key == "ms_730_RD" else (-10, 35))
        hi_c = min(hi, lim[1]); lo_c = max(lo, lim[0])
        ax.plot([lo_c, hi_c], [yi, yi], color=CA if main else "#555", lw=1.2)
        if lo < lim[0]: ax.annotate("", xy=(lim[0], yi), xytext=(lim[0] * (1.05 if log else 1) + (0 if log else 1), yi), arrowprops=dict(arrowstyle="->", color="#555", lw=1))
        if hi > lim[1]: ax.annotate("", xy=(lim[1], yi), xytext=(lim[1] - (0.01 if log else 1), yi), arrowprops=dict(arrowstyle="->", color="#555", lw=1))
        ax.plot([e], [yi], marker="D" if main else "s", color=CA if main else INK, ms=5 if main else 4)
    ax.axvline(1 if log else 0, color=GR, lw=0.8, ls="--")
    if log:
        ax.set_xscale("log"); ax.set_xlim(0.3, 4); ax.set_xticks([0.5, 1, 2, 4]); ax.set_xticklabels(["0.5", "1", "2", "4"]); ax.xaxis.set_minor_locator(matplotlib.ticker.NullLocator())
    else:
        ax.set_xlim(*((-40, 20) if key == "ms_730_RD" else (-10, 35)))
        ax.set_xticks([-40, -20, 0] if key == "ms_730_RD" else [0, 10, 20, 30])
    ax.set_title(title, loc="left"); ax.grid(axis="x", color="#e1e0d9", lw=0.5); ax.set_axisbelow(True)
    ax.tick_params(axis="y", length=0)
axs[0].set_yticks(y); axs[0].set_yticklabels([r[0] or "" for r in rows])
axs[0].text(-39, y[11] + 0.1, "— 亚组与风险分层 —", fontsize=7.5, color="#555", va="center")
axs[0].text(19.5, -1.4, "← 利于早期清除", fontsize=7, color="#555", ha="right")
axs[1].text(34.5, -1.4, "利于单纯抗凝 →", fontsize=7, color="#555", ha="right")
axs[2].text(3.9, -1.4, "利于早期清除 →", fontsize=7, color="#555", ha="right")
for ax in axs: ax.set_ylim(-2, n)
fig.savefig("fig/fig4.png", bbox_inches="tight"); print("ok")
