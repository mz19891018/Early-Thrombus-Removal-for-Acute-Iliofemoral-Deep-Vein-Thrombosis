import numpy as np, pickle, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
fm.fontManager.addfont("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
plt.rcParams.update({"font.family": "Noto Sans CJK JP", "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#c3c2b7", "savefig.dpi": 300, "axes.titlesize": 9, "axes.titleweight": "bold"})
CA, GR, INK = "#2a78d6", "#9a9a92", "#222"
R = pickle.load(open("res_slcf.pkl", "rb"))
fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.7), gridspec_kw=dict(wspace=0.38))
tau = R["tau"] * 100
axs[0].hist(tau, bins=30, color=CA, rwidth=0.9)
axs[0].axvline(0, color=GR, ls="--", lw=0.8); axs[0].axvline(tau.mean(), color=INK, lw=1)
axs[0].set_xlabel("个体化效应 CATE（中重度 PTS，百分点）"); axs[0].set_ylabel("患者数"); axs[0].set_title("A  CATE 分布", loc="left")
for i, (g, n, pred, m, lo, hi) in enumerate(R["gates"]):
    axs[1].plot([i, i], [lo * 100, hi * 100], color="#555", lw=1.2); axs[1].plot(i, m * 100, "s", color=INK, ms=5)
    axs[1].plot(i + 0.18, pred * 100, "D", color=CA, ms=4.5)
axs[1].axhline(0, color=GR, ls="--", lw=0.8); axs[1].set_xticks([0, 1, 2]); axs[1].set_xticklabels(["预测获益\n最大 1/3", "中间 1/3", "预测获益\n最小 1/3"])
axs[1].set_ylabel("RD（百分点）"); axs[1].set_title("B  按预测 CATE 分组", loc="left")
from matplotlib.lines import Line2D
axs[1].legend(handles=[Line2D([], [], marker="s", color=INK, lw=0, label="双稳健估计（95% CI）"), Line2D([], [], marker="D", color=CA, lw=0, label="森林预测均值")], frameon=False, fontsize=6.5, loc="upper center", bbox_to_anchor=(0.5, 1.0))
qs = np.arange(1, 101) / 100
k = qs >= 0.05
axs[2].plot(qs[k] * 100, R["rate"]["toc"][k] * 100, color=CA, lw=2); axs[2].axhline(0, color=GR, ls="--", lw=0.8)
a = R["rate"]["autoc"]
axs[2].set_xlabel("按预测获益排序优先治疗的比例（%）"); axs[2].set_ylabel("相对 ATE 的额外获益（百分点）")
axs[2].set_title("C  TOC 曲线", loc="left"); axs[2].set_xlim(0, 102); axs[2].set_xticks([0, 50, 100]); axs[2].text(0.97, 0.04, f"AUTOC {a[0]*100:.1f}（SE {a[1]*100:.1f}）\nP = {a[2]:.2f}", transform=axs[2].transAxes, ha="right", va="bottom", fontsize=7)
for ax in axs: ax.grid(axis="y", color="#e1e0d9", lw=0.5); ax.set_axisbelow(True)
fig.savefig("fig/figS5_cf.png", bbox_inches="tight"); print("ok")
