import numpy as np, pickle, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import FancyBboxPatch
from core import *

for f in ["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"]:
    fm.fontManager.addfont(f)
plt.rcParams.update({"font.family": "Noto Sans CJK JP", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.edgecolor": "#c3c2b7", "axes.linewidth": 0.8,
                     "xtick.color": "#555", "ytick.color": "#555", "axes.labelcolor": "#333",
                     "axes.titlesize": 10, "axes.titleweight": "bold", "savefig.dpi": 300})
CA, CB, GR, INK = "#2a78d6", "#eb6834", "#9a9a92", "#222222"
d, v = load()
cl = build_clones(d)
OUT = "/home/claude/work/fig"
import os; os.makedirs(OUT, exist_ok=True)

# ---------------- Figure 1: design + flow
fig = plt.figure(figsize=(7.2, 6.2))
ax = fig.add_axes([0, 0.42, 1, 0.58]); ax.axis("off"); ax.set_xlim(0, 100); ax.set_ylim(0, 60)


def box(x, y, w, h, txt, fc="#f4f3ee", ec="#c3c2b7", fs=8.5, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=1.2", fc=fc, ec=ec, lw=0.8))
    ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", fontsize=fs, color=INK, fontweight="bold" if bold else "normal", linespacing=1.35)


def arrow(x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", color="#777", lw=0.8))


n = len(d); nA = int(d.trt.sum()); nB = n - nA
box(30, 51, 40, 7.5, f"4 家中心急性髂股静脉 DVT 患者，2016–2024 年\n符合目标试验纳入/排除标准  n = {n}", bold=True)
arrow(50, 51, 50, 46.5)
box(30, 40, 40, 6, "零时点（影像确诊日）：每例患者复制为两份克隆", fc="#ffffff")
arrow(42, 40, 25, 35.5); arrow(58, 40, 75, 35.5)
box(3, 27, 44, 8, "策略 A：7 天内血栓清除 + 抗凝\n克隆数 740", fc="#e7f0fb", ec=CA, bold=True)
box(53, 27, 44, 8, "策略 B：单纯抗凝\n克隆数 740", fc="#fdece4", ec=CB, bold=True)
arrow(25, 27, 25, 22.5); arrow(75, 27, 75, 22.5)
dd = d.tday[d.trt == 1]
box(3, 9, 44, 13, f"宽限期内删失：{nB} 例\n（第 7 天末仍未介入）\n宽限期内结局事件：1 例（第 5 天复发 DVT）\n\n继续随访并加权：{nA} 例", fc="#ffffff", fs=8)
box(53, 9, 44, 13, f"宽限期内删失：{nA} 例\n（介入当日删失，中位第 {dd.median():.0f} 天）\n宽限期内结局事件：1 例（第 5 天复发 DVT）\n\n继续随访并加权：{nB} 例", fc="#ffffff", fs=8)
box(3, 0.5, 44, 6, f"24 个月 Villalta 评估：{int(d.v24[d.trt==1].notna().sum())} 例；失访 {int(d.ltfu[d.trt==1].sum())} 例；死亡 {int(d.death[d.trt==1].sum())} 例", fc="#ffffff", fs=7.8)
box(53, 0.5, 44, 6, f"24 个月 Villalta 评估：{int(d.v24[d.trt==0].notna().sum())} 例；失访 {int(d.ltfu[d.trt==0].sum())} 例；死亡 {int(d.death[d.trt==0].sum())} 例", fc="#ffffff", fs=7.8)
arrow(25, 9, 25, 7); arrow(75, 9, 75, 7)
ax.text(0, 59.5, "A", fontsize=12, fontweight="bold")

# timeline
ax2 = fig.add_axes([0.08, 0.05, 0.88, 0.32])
ax2.set_xlim(-1, 25); ax2.set_ylim(-0.6, 5.2)
ax2.spines["left"].set_visible(False); ax2.set_yticks([])
ax2.set_xticks([0, 7, 14, 21])
ax2.set_xticklabels(["0\n零时点", "7\n宽限期末", "", ""])
ax2.axvspan(0, 7, color="#f1f0ea", zorder=0)
ax2.text(3.5, 5.0, "宽限期（0–7 天）", ha="center", fontsize=8, color="#555")
cases = [("介入于第 3 天", 3, None), ("全程未介入", None, None), ("第 5 天复发 DVT，未介入", None, 5)]
y = 4.0
for lab, td, ev in cases:
    ax2.text(-0.8, y + 0.05, lab, ha="right", va="center", fontsize=8)
    # arm A
    if td is not None:
        ax2.plot([0, 24], [y + 0.25, y + 0.25], color=CA, lw=2); ax2.plot([td], [y + 0.25], marker="v", color=CA, ms=6)
        ax2.plot([0, td], [y - 0.25, y - 0.25], color=CB, lw=2); ax2.plot([td], [y - 0.25], marker="x", color=CB, ms=7, mew=2)
    elif ev is not None:
        ax2.plot([0, ev], [y + 0.25, y + 0.25], color=CA, lw=2); ax2.plot([ev], [y + 0.25], marker="o", color=CA, ms=6)
        ax2.plot([0, ev], [y - 0.25, y - 0.25], color=CB, lw=2); ax2.plot([ev], [y - 0.25], marker="o", color=CB, ms=6)
    else:
        ax2.plot([0, 7], [y + 0.25, y + 0.25], color=CA, lw=2); ax2.plot([7], [y + 0.25], marker="x", color=CA, ms=7, mew=2)
        ax2.plot([0, 24], [y - 0.25, y - 0.25], color=CB, lw=2)
    y -= 1.6
ax2.set_xticks([0, 7]); ax2.set_xlabel("确诊后天数（示意，未按比例）", fontsize=8)
from matplotlib.lines import Line2D
h = [Line2D([], [], color=CA, lw=2, label="策略 A 克隆"), Line2D([], [], color=CB, lw=2, label="策略 B 克隆"),
     Line2D([], [], color="#555", marker="v", lw=0, label="血栓清除"), Line2D([], [], color="#555", marker="x", mew=2, lw=0, label="人为删失"),
     Line2D([], [], color="#555", marker="o", lw=0, label="结局事件（两臂均计入）")]
ax2.legend(handles=h, loc="lower right", fontsize=7, frameon=False, ncol=2)
fig.text(0.0, 0.385, "B", fontsize=12, fontweight="bold")
fig.savefig(f"{OUT}/fig1.png", bbox_inches="tight"); plt.close(fig)

# ---------------- Figure 3: weighted cumulative incidence curves
panels = [("ms", "A  中重度 PTS（Villalta ≥10 或溃疡）"), ("any", "B  任意 PTS（Villalta ≥5）"),
          ("mb", "C  ISTH 大出血"), ("vte", "D  复发 VTE")]
M = pickle.load(open("/home/claude/work/res_main.pkl", "rb"))["main"]
fig, axs = plt.subplots(2, 2, figsize=(7.2, 5.8))
for ax, (k, title) in zip(axs.ravel(), panels):
    for arm, col, lab in (("A", CA, "早期血栓清除"), ("B", CB, "单纯抗凝")):
        _, st = wAJ(cl[arm], k)
        tt = np.append(st[:, 0], 730); ff = np.append(st[:, 1], st[-1, 1])
        ax.step(tt / 30.44, ff * 100, where="post", color=col, lw=2, label=lab)
        ax.text(24.4, ff[-1] * 100, f"{ff[-1]*100:.1f}%", color=INK, fontsize=8, va="center")
    rd = M[f"{k}_730_RD"]
    ax.set_title(title, loc="left")
    ax.text(0.03, 0.95, f"24 个月 RD {rd[0]*100:+.1f}%\n(95% CI {rd[1]*100:+.1f} 至 {rd[2]*100:+.1f})", transform=ax.transAxes, va="top", fontsize=8, color="#333")
    ax.set_xlim(0, 27.5); ax.set_xticks([0, 6, 12, 18, 24])
    ax.grid(axis="y", color="#e1e0d9", lw=0.6); ax.set_axisbelow(True)
    ax.set_xlabel("确诊后月数"); ax.set_ylabel("累积发生率（%）")
    top = {"ms": 50, "any": 100, "mb": 12, "vte": 14}[k]; ax.set_ylim(0, top)
axs[0, 0].legend(loc="lower right", frameon=False, fontsize=8)
fig.tight_layout(); fig.savefig(f"{OUT}/fig3.png", bbox_inches="tight"); plt.close(fig)

# ---------------- Figure 2: win ratio by tier
tiers = [("death", "1 全因死亡"), ("vte", "2 复发 VTE"), ("mb", "3 大出血"), ("ms", "4 中重度 PTS"), ("any", "5 任意 PTS")]
fig, ax = plt.subplots(figsize=(7.2, 3.4))
ys = np.arange(len(tiers))[::-1]
for y, (k, lab) in zip(ys, tiers):
    w = M[f"tier_{k}_W"][0] * 100; l = M[f"tier_{k}_L"][0] * 100
    ax.barh(y + 0.19, w, height=0.36, color=CA)
    ax.barh(y - 0.19, l, height=0.36, color=CB)
    ax.text(w + 0.4, y + 0.19, f"{w:.1f}%", va="center", fontsize=8, color=INK)
    ax.text(l + 0.4, y - 0.19, f"{l:.1f}%", va="center", fontsize=8, color=INK)
ax.set_yticks(ys); ax.set_yticklabels([t[1] for t in tiers])
ax.set_xlabel("各层判定的配对比例（加权，占全部配对 %）")
ax.grid(axis="x", color="#e1e0d9", lw=0.6); ax.set_axisbelow(True); ax.set_xlim(0, 28)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=CA, label="早期血栓清除胜"), Patch(color=CB, label="单纯抗凝胜")], frameon=False, loc="lower right", fontsize=8)
wr = M["WR"]; wo = M["WO"]
ax.set_title(f"总胜 {M['pW'][0]*100:.1f}%｜总负 {M['pL'][0]*100:.1f}%｜平局 {M['pT'][0]*100:.1f}%    Win ratio {wr[0]:.2f}（95% CI {wr[1]:.2f}–{wr[2]:.2f}），P = {wr[3]:.2f}", loc="left", fontsize=8.5, fontweight="normal")
fig.tight_layout(); fig.savefig(f"{OUT}/fig2.png", bbox_inches="tight"); plt.close(fig)

# ---------------- Figure S1: Love plot
D = pickle.load(open("/home/claude/work/res_desc.pkl", "rb"))
t = D["table2"].iloc[::-1]
fig, ax = plt.subplots(figsize=(6, 6.8))
y = np.arange(len(t))
ax.scatter(t.smd_crude.abs(), y, color=GR, s=28, label="加权前", zorder=3)
ax.scatter(t.smd_w.abs(), y, color=CA, s=28, label="CCW 加权后", zorder=3)
ax.axvline(0.1, color="#777", ls="--", lw=0.8)
ax.set_yticks(y); ax.set_yticklabels(t.label, fontsize=8)
ax.set_xlabel("|标准化均数差|"); ax.grid(axis="x", color="#e1e0d9", lw=0.6); ax.set_axisbelow(True)
ax.legend(frameon=False, loc="lower right")
fig.tight_layout(); fig.savefig(f"{OUT}/figS1.png", bbox_inches="tight"); plt.close(fig)

# ---------------- Figure S2: probability of early removal + weights
W = pickle.load(open("/home/claude/work/res_w.pkl", "rb"))
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.9))
bins = np.linspace(0, 1, 31)
axs[0].hist(W["pA"][W["a"]], bins=bins, color=CA, alpha=0.75, label="早期血栓清除", rwidth=0.92)
axs[0].hist(W["pA"][~W["a"]], bins=bins, color=CB, alpha=0.6, label="单纯抗凝", rwidth=0.92)
axs[0].set_xlabel("7 天内接受血栓清除的预测概率"); axs[0].set_ylabel("患者数"); axs[0].legend(frameon=False, fontsize=8)
axs[0].set_title("A  倾向概率分布重叠", loc="left")
sw = np.where(W["a"], W["w"] * W["a"].mean(), W["w"] * (1 - W["a"].mean()))
axs[1].hist(sw[W["a"]], bins=30, color=CA, alpha=0.75, label="早期血栓清除", rwidth=0.92)
axs[1].hist(sw[~W["a"]], bins=30, color=CB, alpha=0.6, label="单纯抗凝", rwidth=0.92)
axs[1].set_xlabel("稳定化权重（截尾于 P99）"); axs[1].set_title("B  权重分布", loc="left")
fig.tight_layout(); fig.savefig(f"{OUT}/figS2.png", bbox_inches="tight"); plt.close(fig)

# ---------------- Figure S3: Villalta and VEINES-QOL trajectories
tr = D["traj"]
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.9))
ms = [6, 12, 18, 24]
for arm, col, lab in ((1, CA, "早期血栓清除"), (0, CB, "单纯抗凝")):
    for ax, key in zip(axs, ["villalta", "qol"]):
        m = np.array([tr[(x, arm)][key] for x in ms]); sd = np.array([tr[(x, arm)][key + "_sd"] for x in ms])
        n = np.array([tr[(x, arm)]["n"] for x in ms]); se = sd / np.sqrt(n)
        off = -0.25 if arm == 1 else 0.25
        ax.errorbar(np.array(ms) + off, m, yerr=1.96 * se, color=col, lw=2, marker="o", ms=5, capsize=2, label=lab)
axs[0].set_title("A  Villalta 总分", loc="left"); axs[1].set_title("B  VEINES-QOL 评分", loc="left")
for ax in axs:
    ax.set_xticks(ms); ax.set_xlabel("随访月份"); ax.grid(axis="y", color="#e1e0d9", lw=0.6); ax.set_axisbelow(True)
axs[0].set_ylabel("加权均值（95% CI）"); axs[0].legend(frameon=False, fontsize=8)
fig.tight_layout(); fig.savefig(f"{OUT}/figS3.png", bbox_inches="tight"); plt.close(fig)
print("ok")
