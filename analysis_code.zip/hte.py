import numpy as np, pandas as pd, pickle
from core import *
from core import _std
from analysis import estimate, bootstrap, summarize, landmark_data, binary_y, d0
from sklearn.metrics import roc_auc_score
from scipy.stats import norm

R = {}
d = d0
# ---- risk model (PATH): fit on whole cohort with treatment term, predict under anticoagulation alone
y, obs = binary_y(d, "ms")
X = _std(covmat(d)); a = d.trt.values
XA = np.column_stack([X, a])
m = fit_logit(XA[obs], y[obs], C=1.0)
risk0 = m.predict_proba(np.column_stack([X, np.zeros(len(a))]))[:, 1]
auc = roc_auc_score(y[obs & (a == 0)], risk0[obs & (a == 0)])
# optimism-corrected AUC by bootstrap
rng = np.random.default_rng(7); opt = []
for b in range(200):
    ix = rng.choice(np.where(obs)[0], obs.sum(), replace=True)
    mb_ = fit_logit(XA[ix], y[ix], C=1.0)
    p_b = mb_.predict_proba(XA[ix])[:, 1]; p_o = mb_.predict_proba(XA[obs])[:, 1]
    opt.append(roc_auc_score(y[ix], p_b) - roc_auc_score(y[obs], p_o))
auc_all = roc_auc_score(y[obs], m.predict_proba(XA[obs])[:, 1])
R["risk_model"] = dict(auc_ctrl=auc, auc_app=auc_all, auc_opt=auc_all - np.mean(opt))
cuts = np.quantile(risk0, [1 / 3, 2 / 3])
grp = np.digitize(risk0, cuts)
R["risk_cuts"] = cuts
print(R["risk_model"], cuts)
for g in range(3):
    sel = grp == g
    pt = estimate(d.loc[sel].reset_index(drop=True), wr=True)
    bs = bootstrap(estimate, {}, 300, 5000 + g, dsel=sel)
    R[f"risk{g}"] = dict(summ=summarize(pt, bs), n=int(sel.sum()), nA=int(a[sel].sum()),
                         pred=(risk0[sel].mean(), risk0[sel].min(), risk0[sel].max()))
    s = R[f"risk{g}"]["summ"]
    print(g, sel.sum(), {k: tuple(round(x, 3) for x in s[k]) for k in ["ms_730_A", "ms_730_B", "ms_730_RD", "mb_730_RD", "WR"]}, flush=True)

# ---- tipping point (24-month cumulative moderate-to-severe PTS, binary, IPTW)
W = pickle.load(open("res_w.pkl", "rb"))
w = W["w"]; arm = W["a"]
miss = ~obs


def rd_with(rA, rB):
    yy = np.where(obs, y, np.where(arm, rA, rB))
    m1 = np.sum(w[arm] * yy[arm]) / w[arm].sum(); m0 = np.sum(w[~arm] * yy[~arm]) / w[~arm].sum()
    se1 = np.sqrt(np.sum(w[arm] ** 2 * (yy[arm] - m1) ** 2)) / w[arm].sum()
    se0 = np.sqrt(np.sum(w[~arm] ** 2 * (yy[~arm] - m0) ** 2)) / w[~arm].sum()
    diff = m1 - m0; se = np.sqrt(se1 ** 2 + se0 ** 2)
    return diff, diff - 1.96 * se, diff + 1.96 * se


obsrate = {1: np.sum(w[arm & obs] * y[arm & obs]) / w[arm & obs].sum(), 0: np.sum(w[~arm & obs] * y[~arm & obs]) / w[~arm & obs].sum()}
grid = np.round(np.arange(0, 1.01, 0.05), 2)
tp = {}
for rB in [0.0, round(obsrate[0], 3)]:
    for rA in grid:
        tp[(rA, rB)] = rd_with(rA, rB)
R["tipping"] = dict(table=tp, nmiss_A=int((miss & arm).sum()), nmiss_B=int((miss & ~arm).sum()), obsrate=obsrate,
                    cc=rd_with(np.nan, np.nan) if False else None)
# complete-case estimate
cc = obs
m1 = np.sum(w[arm & cc] * y[arm & cc]) / w[arm & cc].sum(); m0 = np.sum(w[~arm & cc] * y[~arm & cc]) / w[~arm & cc].sum()
R["tipping"]["cc"] = (m1, m0)
for rB in [0.0, round(obsrate[0], 3)]:
    first = next((rA for rA in grid if tp[(rA, rB)][2] >= 0), None)
    firstpt = next((rA for rA in grid if tp[(rA, rB)][0] >= 0), None)
    R["tipping"][f"tip_rB{rB}"] = (first, firstpt)
print(R["tipping"]["nmiss_A"], R["tipping"]["nmiss_B"], obsrate, R["tipping"]["cc"],
      {k: v for k, v in R["tipping"].items() if k.startswith("tip")})

# ---- measured-confounder benchmark for E-value: strongest association with treatment and outcome
bench = []
for c in ["age", "iliac", "mts", "extent", "symdur", "pain", "stroke", "bleedscore", "c3", "c4", "bmi"]:
    x = d[c].values.astype(float)
    if set(np.unique(x)) <= {0, 1}:
        hi = x == 1
    else:
        hi = x > np.median(x)
    rr_t = a[hi].mean() / a[~hi].mean()
    rr_y = y[obs & hi].mean() / y[obs & ~hi].mean()
    bench.append((c, rr_t, rr_y))
R["bench"] = bench
print(bench)
pickle.dump(R, open("res_hte.pkl", "wb"))
