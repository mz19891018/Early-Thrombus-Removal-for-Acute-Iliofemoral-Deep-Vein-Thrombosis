// Render blocks.json -> manuscript.docx
const fs = require("fs");
const D = require("docx");
const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
  WidthType, BorderStyle, ImageRun, ShadingType, Footer, PageNumber, PageBreak, LevelFormat } = D;

const blocks = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const FONT = { ascii: "Times New Roman", hAnsi: "Times New Roman", eastAsia: "宋体" };
const HFONT = { ascii: "Times New Roman", hAnsi: "Times New Roman", eastAsia: "黑体" };

// inline markup: **bold**, ^sup^, ~sub~, _italic_
function runs(text, base = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|\^[^^]+\^|~[^~]+~|_[^_]+_)/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), font: FONT, ...base }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, font: FONT, ...base }));
    else if (t.startsWith("^")) out.push(new TextRun({ text: t.slice(1, -1), superScript: true, font: FONT, ...base }));
    else if (t.startsWith("~")) out.push(new TextRun({ text: t.slice(1, -1), subScript: true, font: FONT, ...base }));
    else out.push(new TextRun({ text: t.slice(1, -1), italics: true, font: FONT, ...base }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), font: FONT, ...base }));
  return out;
}

const thin = { style: BorderStyle.SINGLE, size: 4, color: "000000" };
const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const PAGEW = 11906 - 2 * 1300; // A4 minus margins

function table(b) {
  const n = b.header.length;
  const widths = b.widths ? b.widths.map(w => Math.round(w * PAGEW)) : Array(n).fill(Math.floor(PAGEW / n));
  const tw = widths.reduce((a, c) => a + c, 0);
  const mk = (cells, isHead, isLast) => new TableRow({
    tableHeader: isHead,
    children: cells.map((c, i) => {
      const txt = String(c);
      const indent = txt.startsWith("  ");
      return new TableCell({
        width: { size: widths[i], type: WidthType.DXA },
        borders: { top: isHead ? thin : none, bottom: (isHead || isLast) ? thin : none, left: none, right: none },
        margins: { top: 30, bottom: 30, left: 70, right: 70 },
        children: [new Paragraph({
          alignment: i === 0 ? AlignmentType.LEFT : AlignmentType.CENTER,
          indent: indent ? { left: 200 } : undefined,
          spacing: { line: 260 },
          children: runs(txt.trim(), { size: 17, bold: isHead }),
        })],
      });
    }),
  });
  const rows = [mk(b.header, true, false)];
  b.rows.forEach((r, k) => rows.push(mk(r, false, k === b.rows.length - 1)));
  return new Table({ width: { size: tw, type: WidthType.DXA }, columnWidths: widths, rows });
}

const children = [];
for (const b of blocks) {
  if (b.type === "title") children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: b.text, bold: true, size: 32, font: HFONT })] }));
  else if (b.type === "subtitle") children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: runs(b.text, { size: 21 }) }));
  else if (b.type === "h1") children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 280, after: 140 }, children: [new TextRun({ text: b.text, bold: true, size: 28, font: HFONT })] }));
  else if (b.type === "h2") children.push(new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 200, after: 100 }, children: [new TextRun({ text: b.text, bold: true, size: 24, font: HFONT })] }));
  else if (b.type === "h3") children.push(new Paragraph({ heading: HeadingLevel.HEADING_3, spacing: { before: 140, after: 80 }, children: [new TextRun({ text: b.text, bold: true, size: 21, font: HFONT })] }));
  else if (b.type === "p") children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, indent: b.noindent ? undefined : { firstLine: 420 }, spacing: { line: 360, after: 60 }, children: runs(b.text, { size: 21 }) }));
  else if (b.type === "abs") children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { line: 340, after: 80 }, children: runs(b.text, { size: 21 }) }));
  else if (b.type === "ref") children.push(new Paragraph({ indent: { left: 420, hanging: 420 }, spacing: { line: 300, after: 40 }, children: runs(b.text, { size: 19 }) }));
  else if (b.type === "bullet") children.push(new Paragraph({ numbering: { reference: "bul", level: 0 }, spacing: { line: 340, after: 40 }, children: runs(b.text, { size: 21 }) }));
  else if (b.type === "caption") children.push(new Paragraph({ alignment: AlignmentType.LEFT, keepNext: !!b.keep, spacing: { before: 200, after: 80 }, children: runs(b.text, { size: 19, bold: false }) }));
  else if (b.type === "note") children.push(new Paragraph({ spacing: { before: 40, after: 160, line: 260 }, children: runs(b.text, { size: 16 }) }));
  else if (b.type === "table") children.push(table(b));
  else if (b.type === "img") {
    const buf = fs.readFileSync(b.path);
    const w = b.width || 600; const h = Math.round(w * b.ratio);
    children.push(new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, keepLines: true, spacing: { before: 120 }, children: [new ImageRun({ data: buf, type: "png", transformation: { width: w, height: h } })] }));
  } else if (b.type === "pagebreak") children.push(new Paragraph({ children: [new PageBreak()] }));
}

const doc = new Document({
  styles: { default: { document: { run: { font: "Times New Roman", size: 21 } } } },
  numbering: { config: [{ reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 640, hanging: 320 } } } }] }] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1300, bottom: 1300, left: 1300, right: 1300 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], size: 18 })] })] }) },
    children,
  }],
});
Packer.toBuffer(doc).then(buf => { fs.writeFileSync(process.argv[3], buf); console.log("written", process.argv[3]); });
