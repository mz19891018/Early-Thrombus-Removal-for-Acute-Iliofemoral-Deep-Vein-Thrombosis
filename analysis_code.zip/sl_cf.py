"""Cross-fitted SuperLearner AIPW and causal forest (exploratory) on landmark data."""
import numpy as np, pandas as pd, pickle, warnings
from scipy.optimize import minimize
from scipy.stats import norm
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import SplineTransformer, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.compose import ColumnTransformer
from sklearn.base import clone
from core import load, covmat, COV_CONT, COV_BIN, COV_CTR, HORIZON
from analysis import landmark_data
warnings.filterwarnings("ignore")

d0, _ = load()
d = landmark_data(d0)
COLS = COV_CONT + COV_BIN + COV_CTR
X = d[COLS].astype(float).values
A = d.trt.values.astype(int)
ncont = len(COV_CONT)


def binary(key):
    if key in ("ms", "any"):
        y = d[key + "_t"].notna().values.astype(int)
        obs = (y == 1) | (d.ptsfu.values >= HORIZON) | (d.death.values == 1)
    else:  # clinical event
        y = (d[key].values == 1).astype(int)
        obs = (y == 1) | (d.fu.values >= HORIZON) | (d.death.values == 1)
    return y, obs


# ------------------------------------------------------------------ SuperLearner
def library():
    spl = ColumnTransformer([("s", SplineTransformer(n_knots=4, degree=3), list(range(ncont)))], remainder="passthrough")
    return {
        "mean": None,
        "logistic": make_pipeline(StandardScaler(), LogisticRegression(C=1.0, max_iter=5000)),
        "logistic_l1": make_pipeline(StandardScaler(), LogisticRegression(C=0.1, penalty="l1", solver="liblinear")),
        "gam_spline": make_pipeline(spl, StandardScaler(), LogisticRegression(C=0.5, max_iter=5000)),
        "random_forest": RandomForestClassifier(n_estimators=500, min_samples_leaf=15, max_features="sqrt", n_jobs=2, random_state=1),
        "gbm": GradientBoostingClassifier(n_estimators=150, max_depth=2, learning_rate=0.05, subsample=0.8, random_state=1),
    }


def _fit_pred(m, Xtr, ytr, Xte):
    if m is None or len(np.unique(ytr)) < 2:
        return np.full(len(Xte), ytr.mean())
    mm = clone(m); mm.fit(Xtr, ytr)
    return mm.predict_proba(Xte)[:, 1]


class SuperLearner:
    def __init__(self, V=5, seed=0):
        self.V, self.seed = V, seed

    def fit(self, Xa, y):
        lib = library(); self.names = list(lib)
        Z = np.zeros((len(y), len(lib)))
        skf = StratifiedKFold(self.V, shuffle=True, random_state=self.seed)
        for tr, te in skf.split(Xa, y):
            for j, (k, m) in enumerate(lib.items()):
                Z[te, j] = _fit_pred(m, Xa[tr], y[tr], Xa[te])
        Z = np.clip(Z, 1e-4, 1 - 1e-4)
        def loss(w):
            p = np.clip(Z @ w, 1e-4, 1 - 1e-4)
            return -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))
        k = Z.shape[1]
        r = minimize(loss, np.full(k, 1 / k), bounds=[(0, 1)] * k, constraints=[{"type": "eq", "fun": lambda w: w.sum() - 1}], method="SLSQP")
        self.w = r.x
        self.cvrisk = {n: -np.mean(y * np.log(Z[:, j]) + (1 - y) * np.log(1 - Z[:, j])) for j, n in enumerate(self.names)}
        self.fitted = [None if m is None else clone(m).fit(Xa, y) if len(np.unique(y)) > 1 else None for m in lib.values()]
        self.ybar = y.mean()
        return self

    def predict(self, Xa):
        P = np.column_stack([np.full(len(Xa), self.ybar) if m is None else m.predict_proba(Xa)[:, 1] for m in self.fitted])
        return np.clip(P @ self.w, 1e-4, 1 - 1e-4)


def crossfit_nuisance(y, obs, K=5, seed=0):
    """Cross-fitted e(X), pr(R=1|X,A), mu1(X), mu0(X). Returns arrays + SL weights."""
    n = len(y)
    e = np.zeros(n); pr = np.zeros(n); mu1 = np.zeros(n); mu0 = np.zeros(n)
    W = {"e": [], "r": [], "mu": []}
    skf = StratifiedKFold(K, shuffle=True, random_state=seed)
    XA = np.column_stack([X, A])
    for tr, te in skf.split(X, A * 2 + obs):
        sl_e = SuperLearner(seed=seed).fit(X[tr], A[tr]); e[te] = sl_e.predict(X[te])
        sl_r = SuperLearner(seed=seed).fit(XA[tr], obs[tr].astype(int)); pr[te] = sl_r.predict(XA[te])
        o = tr[obs[tr]]
        sl_m = SuperLearner(seed=seed).fit(XA[o], y[o])
        mu1[te] = sl_m.predict(np.column_stack([X[te], np.ones(len(te))]))
        mu0[te] = sl_m.predict(np.column_stack([X[te], np.zeros(len(te))]))
        W["e"].append(sl_e.w); W["r"].append(sl_r.w); W["mu"].append(sl_m.w)
    names = sl_e.names
    return e, pr, mu1, mu0, {k: dict(zip(names, np.mean(v, 0))) for k, v in W.items()}, {"e": sl_e.cvrisk, "mu": sl_m.cvrisk}


def aipw_scores(y, obs, e, pr, mu1, mu0):
    e = np.clip(e, 0.01, 0.99); pr = np.clip(pr, 0.05, 1)
    yy = np.where(obs, y, 0)
    g1 = mu1 + A * obs / (e * pr) * (yy - mu1)
    g0 = mu0 + (1 - A) * obs / ((1 - e) * pr) * (yy - mu0)
    return g1, g0


R = {}
for key in ["ms", "any", "mb"]:
    y, obs = binary(key)
    ests = []
    for s in range(5):  # repeated cross-fitting, median aggregation (Chernozhukov et al.)
        e, pr, mu1, mu0, Wsl, risk = crossfit_nuisance(y, obs, seed=s)
        g1, g0 = aipw_scores(y, obs, e, pr, mu1, mu0)
        p1, p0 = g1.mean(), g0.mean(); rd = p1 - p0
        se_rd = np.std(g1 - g0, ddof=1) / np.sqrt(len(y))
        # RR via delta method on log scale
        ifl = (g1 - p1) / p1 - (g0 - p0) / p0
        se_lrr = np.std(ifl, ddof=1) / np.sqrt(len(y))
        ests.append(dict(p1=p1, p0=p0, rd=rd, se_rd=se_rd, rr=p1 / p0, se_lrr=se_lrr, W=Wsl, risk=risk,
                         nuis=(e, pr, mu1, mu0) if s == 0 else None))
    med = lambda k: np.median([x[k] for x in ests])
    rd, rr = med("rd"), med("rr")
    # median-adjusted variance
    se = np.sqrt(np.median([x["se_rd"] ** 2 + (x["rd"] - rd) ** 2 for x in ests]))
    sel = np.sqrt(np.median([x["se_lrr"] ** 2 + (np.log(x["rr"]) - np.log(rr)) ** 2 for x in ests]))
    R[key] = dict(p1=med("p1"), p0=med("p0"), rd=(rd, rd - 1.96 * se, rd + 1.96 * se, 2 * (1 - norm.cdf(abs(rd / se)))),
                  rr=(rr, np.exp(np.log(rr) - 1.96 * sel), np.exp(np.log(rr) + 1.96 * sel)),
                  W=ests[0]["W"], risk=ests[0]["risk"], nobs=int(obs.sum()))
    if key == "ms":
        R["nuis_ms"] = ests[0]["nuis"]
    print(key, {k: (np.round(v, 4) if not isinstance(v, dict) else {kk: {a: round(b, 3) for a, b in vv.items()} if isinstance(vv, dict) else vv for kk, vv in v.items()}) for k, v in R[key].items()}, flush=True)

# ------------------------------------------------------------------ causal forest
from econml.dml import CausalForestDML
y, obs = binary("ms")
e, pr, mu1, mu0 = R["nuis_ms"]
g1, g0 = aipw_scores(y, obs, e, pr, mu1, mu0)
gamma = g1 - g0  # doubly robust scores
Xo, Ao, yo = X[obs], A[obs], y[obs]
sw = 1 / np.clip(pr[obs], 0.05, 1)


def make_cf(seed):
    return CausalForestDML(model_y=GradientBoostingRegressor(n_estimators=150, max_depth=2, learning_rate=0.05, subsample=0.8, random_state=seed),
                           model_t=GradientBoostingClassifier(n_estimators=150, max_depth=2, learning_rate=0.05, subsample=0.8, random_state=seed),
                           discrete_treatment=True, cv=5, n_estimators=2000, min_samples_leaf=10, max_samples=0.5,
                           honest=True, inference=True, random_state=seed)


cf = make_cf(42)
cf.fit(yo, Ao, X=Xo, sample_weight=sw)
ate = cf.ate_inference(X=Xo)
R["cf_ate"] = (ate.mean_point, *ate.conf_int_mean(alpha=0.05))
imp = pd.Series(cf.feature_importances_, index=COLS).sort_values(ascending=False)
R["cf_imp"] = imp
# out-of-fold CATE predictions for all landmark patients (for calibration & RATE)
tau = np.zeros(len(y))
skf = StratifiedKFold(5, shuffle=True, random_state=7)
for tr, te in skf.split(X, A * 2 + obs):
    o = tr[obs[tr]]
    m = make_cf(11); m.fit(y[o], A[o], X=X[o], sample_weight=1 / np.clip(pr[o], 0.05, 1))
    tau[te] = m.effect(X[te])
R["tau"] = tau
R["cate_dist"] = (tau.mean(), np.percentile(tau, [5, 25, 50, 75, 95]), (tau < 0).mean())
# calibration test (grf test_calibration analogue): gamma ~ mean.pred + differential.pred
tc = tau - tau.mean()
Z = np.column_stack([np.full(len(tau), tau.mean()), tc])
b, *_ = np.linalg.lstsq(Z, gamma, rcond=None)
res = gamma - Z @ b
XtX = np.linalg.inv(Z.T @ Z); meat = (Z * res[:, None] ** 2).T @ Z
V = XtX @ meat @ XtX
se_b = np.sqrt(np.diag(V))
R["calib"] = dict(mean_coef=(b[0], se_b[0], 1 - norm.cdf(b[0] / se_b[0])), diff_coef=(b[1], se_b[1], 1 - norm.cdf(b[1] / se_b[1])))
# RATE (AUTOC and Qini) prioritising patients with most negative predicted effect (largest predicted benefit)
order = np.argsort(tau)  # most benefit first
benefit = -gamma  # risk reduction
qs = np.arange(1, 101) / 100


def rate(g, ordr):
    n = len(g); ate_ = g.mean()
    toc = np.array([g[ordr[:max(1, int(np.ceil(q * n)))]].mean() - ate_ for q in qs])
    autoc = toc.mean(); qini = (toc * qs).mean()
    return toc, autoc, qini


toc, autoc, qini = rate(benefit, order)
rng = np.random.default_rng(3); bs = []
for _ in range(1000):
    ix = rng.integers(0, len(benefit), len(benefit))
    _, a_, q_ = rate(benefit[ix], np.argsort(tau[ix])); bs.append((a_, q_))
bs = np.array(bs)
R["rate"] = dict(toc=toc, autoc=(autoc, bs[:, 0].std(), 2 * (1 - norm.cdf(abs(autoc / bs[:, 0].std())))),
                 qini=(qini, bs[:, 1].std(), 2 * (1 - norm.cdf(abs(qini / bs[:, 1].std())))))
# GATES: DR-estimated effect within tertiles of predicted CATE
tert = np.digitize(tau, np.quantile(tau, [1 / 3, 2 / 3]))
R["gates"] = []
for g in range(3):
    s = tert == g; m_ = gamma[s].mean(); se_ = gamma[s].std(ddof=1) / np.sqrt(s.sum())
    R["gates"].append((g, int(s.sum()), tau[s].mean(), m_, m_ - 1.96 * se_, m_ + 1.96 * se_))
# best linear projection of DR scores on key modifiers (robust SE)
mods = ["age", "symdur", "iliac", "mts", "extent", "pain", "bleedscore", "female"]
Zm = np.column_stack([np.ones(len(gamma)), d[mods].astype(float).values])
bm, *_ = np.linalg.lstsq(Zm, gamma, rcond=None); rm = gamma - Zm @ bm
XtX = np.linalg.inv(Zm.T @ Zm); V = XtX @ ((Zm * rm[:, None] ** 2).T @ Zm) @ XtX; sm = np.sqrt(np.diag(V))
R["blp"] = [(mods[i - 1], bm[i], sm[i], 2 * (1 - norm.cdf(abs(bm[i] / sm[i])))) for i in range(1, len(bm))]
R["n_landmark"] = len(d); R["n_obs_ms"] = int(obs.sum())
del R["nuis_ms"]
pickle.dump(R, open("res_slcf.pkl", "wb"))
print("CF ATE", R["cf_ate"]); print("CATE dist", R["cate_dist"]); print("calib", R["calib"])
print("rate", {k: v for k, v in R["rate"].items() if k != "toc"}); print("gates", R["gates"]); print("blp", R["blp"]); print(imp.head(10))
